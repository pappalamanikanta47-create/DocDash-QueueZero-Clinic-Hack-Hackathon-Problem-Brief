import {useState} from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  FileText,
  RotateCcw,
  Siren,
  Stethoscope,
  UserX,
  X,
} from 'lucide-react';
import type {DoctorConsoleData, QueueToken} from '../../shared/types';
import {
  doctorAddDelay,
  doctorCallNext,
  doctorCompleteCurrent,
  doctorEscalateEmergency,
  doctorMarkAbsent,
  restoreAbsentToken,
  updateTokenNotes,
} from '../api';
import {StatusLabel} from './StatusLabel';

interface DoctorConsolePanelProps {
  data: DoctorConsoleData;
  onChangeShift: (shiftId: string) => void;
  onUpdated: (next: DoctorConsoleData) => void;
  compact?: boolean;
}

const NOTE_TEMPLATES = [
  {
    label: 'Cardiology Follow-up',
    notes: 'Blood pressure stable; resting ECG normal sinus rhythm. Continue current lifestyle and cardio exercise plan.',
    rx: 'Telmisartan 40 mg OD (morning) · Atorvastatin 10 mg HS · Follow up in 8 weeks',
  },
  {
    label: 'Acute Care / Viral',
    notes: 'Mild upper respiratory symptoms; lungs clear on auscultation. Hydration and rest advised.',
    rx: 'Paracetamol 500 mg SOS (max 3/day) · Warm saline gargles · Return if fever persists >72h',
  },
];

export function DoctorConsolePanel({
  data,
  onChangeShift,
  onUpdated,
  compact = false,
}: DoctorConsolePanelProps) {
  const {doctor, clinic, shifts, activeShift, currentToken, waitingQueue, absentTokens, completedTokens, auditLogs} =
    data;

  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<{type: 'success' | 'error'; text: string} | null>(null);
  const [paceMode, setPaceMode] = useState<'default' | 'fast' | 'slow'>('default');

  // Visit notes composer modal/drawer state
  const [editingNotesToken, setEditingNotesToken] = useState<QueueToken | null>(null);
  const [visitNotesText, setVisitNotesText] = useState('');
  const [rxText, setRxText] = useState('');

  // Emergency escalation dialog state
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [escalateMode, setEscalateMode] = useState<'walkin' | 'existing'>('walkin');
  const [escalateTokenId, setEscalateTokenId] = useState('');
  const [escalateName, setEscalateName] = useState('');
  const [escalatePhone, setEscalatePhone] = useState('');
  const [escalateReason, setEscalateReason] = useState('');

  const paceDurationOverride = (): number | undefined => {
    if (paceMode === 'fast') return Math.max(5, doctor.defaultDurationMin - 4);
    if (paceMode === 'slow') return doctor.defaultDurationMin + 8;
    return undefined;
  };

  const runAction = async (fn: () => Promise<{console: DoctorConsoleData; message: string}>) => {
    setBusy(true);
    setFeedback(null);
    try {
      const res = await fn();
      onUpdated(res.console);
      setFeedback({type: 'success', text: res.message});
    } catch (err) {
      setFeedback({type: 'error', text: (err as Error).message});
    } finally {
      setBusy(false);
    }
  };

  const handleCallNext = () => {
    void runAction(() => doctorCallNext(doctor.id, activeShift.id, paceDurationOverride()));
  };

  const handleMarkCompleted = async () => {
    setBusy(true);
    setFeedback(null);
    try {
      const res = await doctorCompleteCurrent(doctor.id, {
        shiftId: activeShift.id,
        durationOverrideMin: paceDurationOverride(),
      });
      onUpdated(res.console);
      setFeedback({type: 'success', text: res.message});
      const doneTok = res.console.completedTokens.find((t) => t.id === res.completedTokenId);
      if (doneTok) {
        setEditingNotesToken(doneTok);
        setVisitNotesText(doneTok.visitNotes ?? '');
        setRxText(doneTok.prescriptionSummary ?? '');
      }
    } catch (err) {
      setFeedback({type: 'error', text: (err as Error).message});
    } finally {
      setBusy(false);
    }
  };

  const handleDelay10 = () => {
    void runAction(() =>
      doctorAddDelay(doctor.id, activeShift.id, 10, 'Consultation running +10 minutes over schedule.')
    );
  };

  const handleClearDelay = () => {
    void runAction(() =>
      doctorAddDelay(
        doctor.id,
        activeShift.id,
        -doctor.delayMinutes,
        'Doctor back on schedule; active delay cleared.'
      )
    );
  };

  const handleMarkAbsent = (tokenId?: string) => {
    void runAction(() => doctorMarkAbsent(doctor.id, activeShift.id, tokenId));
  };

  const handleRestoreAbsent = (tokenId: string) => {
    void runAction(() => restoreAbsentToken(tokenId));
  };

  const handleSaveNotes = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingNotesToken) return;
    setBusy(true);
    setFeedback(null);
    try {
      const updatedTok = await updateTokenNotes(editingNotesToken.id, visitNotesText, rxText);
      const nextCompleted = completedTokens.map((t) => (t.id === updatedTok.id ? updatedTok : t));
      onUpdated({
        ...data,
        completedTokens: nextCompleted,
      });
      setEditingNotesToken(null);
      setFeedback({
        type: 'success',
        text: `Saved visit notes and prescription for Token #${updatedTok.tokenNumber}.`,
      });
    } catch (err) {
      setFeedback({type: 'error', text: (err as Error).message});
    } finally {
      setBusy(false);
    }
  };

  const handleEscalateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setFeedback(null);
    try {
      const res = await doctorEscalateEmergency(doctor.id, {
        shiftId: activeShift.id,
        tokenId: escalateMode === 'existing' ? escalateTokenId : undefined,
        patientName: escalateMode === 'walkin' ? escalateName : undefined,
        contactNumber: escalateMode === 'walkin' ? escalatePhone : undefined,
        reason: escalateReason,
        staffActor: 'Authorized Staff / Triage',
      });
      onUpdated(res.console);
      setShowEmergencyModal(false);
      setEscalateName('');
      setEscalatePhone('');
      setEscalateReason('');
      setFeedback({type: 'success', text: res.message});
    } catch (err) {
      setFeedback({type: 'error', text: (err as Error).message});
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header Summary Bar */}
      <section className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-slate-500">
              {clinic.name} · {doctor.roomNumber}
            </p>
            <h2 className="font-display mt-0.5 text-xl font-bold text-slate-900">
              {doctor.name}
            </h2>
            <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-slate-600">
              <span>{doctor.specialty}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">EWMA pace: {doctor.ewmaPaceMin.toFixed(1)} min</span>
              <span aria-hidden="true">·</span>
              <StatusLabel status={doctor.availability} delayMinutes={doctor.delayMinutes} />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
              {shifts.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => onChangeShift(s.id)}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium capitalize transition-colors whitespace-nowrap shrink-0 ${
                    s.id === activeShift.id
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {s.period}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => {
                setEscalateMode(waitingQueue.length > 0 ? 'walkin' : 'walkin');
                setEscalateTokenId(waitingQueue[0]?.id ?? '');
                setShowEmergencyModal(true);
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-800 hover:bg-red-100 whitespace-nowrap shrink-0"
            >
              <Siren className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Emergency Escalation</span>
            </button>
          </div>
        </div>

        {/* Action feedback banner */}
        {feedback && (
          <div
            role="status"
            aria-live="polite"
            className={`mt-4 flex items-center justify-between gap-3 rounded-lg border px-3.5 py-2.5 text-sm ${
              feedback.type === 'success'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                : 'border-red-200 bg-red-50 text-red-900'
            }`}
          >
            <span className="font-medium">{feedback.text}</span>
            <button
              type="button"
              aria-label="Dismiss notification"
              onClick={() => setFeedback(null)}
              className="text-current/70 hover:text-current"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        )}
      </section>

      {/* Now Serving + Core Doctor Control Actions */}
      <section className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2">
            <Stethoscope className="h-4 w-4 text-teal-700" aria-hidden="true" />
            <h3 className="font-display text-base font-bold text-slate-900">
              Active Consultation
            </h3>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Logged duration on advance:</span>
            <select
              aria-label="Consultation duration for EWMA update"
              value={paceMode}
              onChange={(e) => setPaceMode(e.target.value as 'default' | 'fast' | 'slow')}
              className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-medium text-slate-700"
            >
              <option value="default">Baseline ({doctor.defaultDurationMin}m)</option>
              <option value="fast">Quick ({Math.max(5, doctor.defaultDurationMin - 4)}m)</option>
              <option value="slow">Extended ({doctor.defaultDurationMin + 8}m)</option>
            </select>
          </div>
        </div>

        {currentToken ? (
          <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl border border-teal-200 bg-teal-50 font-mono text-2xl font-bold tabular-nums text-teal-800">
                #{currentToken.tokenNumber}
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-display text-lg font-bold text-slate-900">
                    {currentToken.patientName}
                  </p>
                  {currentToken.isEmergency && <StatusLabel status="emergency" />}
                </div>
                <p className="mt-0.5 text-sm text-slate-600">
                  {currentToken.contactNumber}
                  {currentToken.checkedInAt ? ' · Checked in at clinic' : ' · Not yet checked in'}
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-4 rounded-lg border border-dashed border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">
            No patient currently in room.{' '}
            {waitingQueue.length > 0
              ? `Token #${waitingQueue[0].tokenNumber} (${waitingQueue[0].patientName}) is ready to be called.`
              : 'Waiting queue is currently empty.'}
          </div>
        )}

        {/* 4 Required Doctor Controls */}
        <div className="mt-5 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          <button
            type="button"
            disabled={busy || (!currentToken && waitingQueue.length === 0)}
            onClick={handleCallNext}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-teal-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-teal-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <span>Call Next Patient</span>
            <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
          </button>

          <button
            type="button"
            disabled={busy || !currentToken}
            onClick={handleMarkCompleted}
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-emerald-300 bg-emerald-50 px-4 py-2.5 text-sm font-semibold text-emerald-900 hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <CheckCircle2 className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>Mark Completed</span>
          </button>

          <div className="flex gap-2">
            <button
              type="button"
              disabled={busy}
              onClick={handleDelay10}
              className="flex-1 inline-flex items-center justify-center gap-2 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2.5 text-sm font-semibold text-amber-900 hover:bg-amber-100 disabled:opacity-50"
            >
              <Clock className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>Delay 10 Minutes</span>
            </button>
            {doctor.delayMinutes > 0 && (
              <button
                type="button"
                disabled={busy}
                onClick={handleClearDelay}
                className="rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Clear
              </button>
            )}
          </div>

          <button
            type="button"
            disabled={busy || (!currentToken && waitingQueue.length === 0)}
            onClick={() => handleMarkAbsent()}
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-rose-200 bg-rose-50 px-4 py-2.5 text-sm font-semibold text-rose-900 hover:bg-rose-100 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <UserX className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>Patient Absent — Skip Token</span>
          </button>
        </div>
      </section>

      {/* Active Waiting Queue Table */}
      <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3.5">
          <h3 className="font-display text-base font-bold text-slate-900">
            Waiting Queue ({waitingQueue.length})
          </h3>
          <span className="font-mono text-xs tabular-nums text-slate-500">
            Ordered by priority
          </span>
        </div>

        {waitingQueue.length === 0 ? (
          <div className="px-5 py-8 text-center text-sm text-slate-500">
            No patients waiting in {activeShift.label}. New bookings appear here instantaneously.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-xs font-medium text-slate-500">
                  <th className="px-4 py-2.5">Token</th>
                  <th className="px-4 py-2.5">Patient</th>
                  {!compact && <th className="px-4 py-2.5">Arrival</th>}
                  <th className="px-4 py-2.5 text-right">Est. Wait</th>
                  <th className="px-4 py-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {waitingQueue.map((tok) => (
                  <tr key={tok.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3 font-mono font-bold tabular-nums text-slate-900">
                      #{tok.tokenNumber}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium text-slate-900">{tok.patientName}</span>
                        {tok.isEmergency && <StatusLabel status="emergency" />}
                      </div>
                      <p className="text-xs text-slate-500">{tok.contactNumber}</p>
                    </td>
                    {!compact && (
                      <td className="px-4 py-3 text-xs text-slate-600">
                        {tok.checkedInAt ? `Checked in (${tok.checkInDistanceM ?? 0}m)` : 'En route / Remote'}
                      </td>
                    )}
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-700">
                      ~{tok.estimatedWaitMinutes}m
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => handleMarkAbsent(tok.id)}
                        className="rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:border-rose-200 hover:bg-rose-50 hover:text-rose-800"
                      >
                        Skip Absent
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Absent Holding Bay & Completed Visits */}
      <div className={`grid gap-5 ${compact ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-2'}`}>
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <h3 className="font-display text-sm font-bold text-slate-900">
            Absent / Holding Bay ({absentTokens.length})
          </h3>
          {absentTokens.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">
              Skipped patients appear here and can be restored without blocking active consultations.
            </p>
          ) : (
            <ul className="mt-3 divide-y divide-slate-100">
              {absentTokens.map((tok) => (
                <li key={tok.id} className="flex items-center justify-between gap-3 py-2.5">
                  <div>
                    <span className="font-mono text-sm font-bold tabular-nums text-slate-900">
                      #{tok.tokenNumber}
                    </span>{' '}
                    <span className="text-sm font-medium text-slate-800">{tok.patientName}</span>
                    <p className="text-xs text-slate-500">{tok.contactNumber}</p>
                  </div>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => handleRestoreAbsent(tok.id)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-teal-200 bg-teal-50 px-3 py-1.5 text-xs font-semibold text-teal-800 hover:bg-teal-100 whitespace-nowrap shrink-0"
                  >
                    <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Restore to Queue</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <h3 className="font-display text-sm font-bold text-slate-900">
            Completed Visits ({completedTokens.length})
          </h3>
          {completedTokens.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">Completed tokens will appear here for visit notes.</p>
          ) : (
            <ul className="mt-3 divide-y divide-slate-100 max-h-60 overflow-y-auto">
              {completedTokens.slice(0, 6).map((tok) => (
                <li key={tok.id} className="flex items-center justify-between gap-3 py-2.5">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold tabular-nums text-slate-900">
                        #{tok.tokenNumber}
                      </span>
                      <span className="truncate text-sm font-medium text-slate-800">
                        {tok.patientName}
                      </span>
                      {tok.durationMinutes && (
                        <span className="font-mono text-xs tabular-nums text-slate-500">
                          · {tok.durationMinutes}m
                        </span>
                      )}
                    </div>
                    <p className="truncate text-xs text-slate-500">
                      {tok.visitNotes ? 'Notes & Rx attached' : 'No visit notes attached yet'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingNotesToken(tok);
                      setVisitNotesText(tok.visitNotes ?? '');
                      setRxText(tok.prescriptionSummary ?? '');
                    }}
                    className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
                  >
                    <FileText className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>{tok.visitNotes ? 'Edit Notes' : 'Attach Notes'}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Audit Log Excerpt */}
      {!compact && auditLogs.length > 0 && (
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <h3 className="font-display text-sm font-bold text-slate-900">
            Recent Clinic Activity &amp; Escalation Audit Log
          </h3>
          <ul className="mt-3 divide-y divide-slate-100 text-xs">
            {auditLogs.slice(0, 5).map((entry) => (
              <li key={entry.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
                <div className="text-slate-700">
                  <span className="font-semibold text-slate-900">{entry.actor}</span> ·{' '}
                  <span>{entry.reason}</span>
                </div>
                <span className="font-mono tabular-nums text-slate-400">
                  {new Date(entry.createdAt).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Visit Notes & Prescription Modal */}
      {editingNotesToken && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
          aria-labelledby="notes-modal-title"
        >
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-6 shadow-xl">
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h3 id="notes-modal-title" className="font-display text-lg font-bold text-slate-900">
                  Visit Summary · Token #{editingNotesToken.tokenNumber}
                </h3>
                <p className="text-xs text-slate-500">
                  Patient: {editingNotesToken.patientName} · Visible immediately on patient tracker
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditingNotesToken(null)}
                aria-label="Close visit notes dialog"
                className="rounded-lg border border-slate-200 p-1.5 text-slate-500 hover:bg-slate-50"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-500">Quick demo templates:</span>
              {NOTE_TEMPLATES.map((tpl) => (
                <button
                  key={tpl.label}
                  type="button"
                  onClick={() => {
                    setVisitNotesText(tpl.notes);
                    setRxText(tpl.rx);
                  }}
                  className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100"
                >
                  {tpl.label}
                </button>
              ))}
            </div>

            <form onSubmit={handleSaveNotes} className="mt-4 space-y-4">
              <div>
                <label htmlFor="visit-notes-input" className="block text-xs font-semibold text-slate-700">
                  Clinical Visit Notes
                </label>
                <textarea
                  id="visit-notes-input"
                  rows={3}
                  value={visitNotesText}
                  onChange={(e) => setVisitNotesText(e.target.value)}
                  placeholder="Enter consultation findings and follow-up guidance..."
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="rx-summary-input" className="block text-xs font-semibold text-slate-700">
                  Prescription Summary
                </label>
                <textarea
                  id="rx-summary-input"
                  rows={2}
                  value={rxText}
                  onChange={(e) => setRxText(e.target.value)}
                  placeholder="Medications, dosage, and instructions..."
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingNotesToken(null)}
                  className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                >
                  Skip
                </button>
                <button
                  type="submit"
                  disabled={busy}
                  className="rounded-lg bg-teal-600 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-700"
                >
                  Save Visit Summary
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Emergency Escalation Modal */}
      {showEmergencyModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
          aria-labelledby="emergency-modal-title"
        >
          <div className="w-full max-w-lg rounded-xl border border-red-200 bg-white p-6 shadow-xl">
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2 text-red-800">
                <AlertTriangle className="h-5 w-5 shrink-0" aria-hidden="true" />
                <h3 id="emergency-modal-title" className="font-display text-lg font-bold">
                  Authorized Staff Emergency Escalation
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowEmergencyModal(false)}
                aria-label="Close emergency escalation dialog"
                className="rounded-lg border border-slate-200 p-1.5 text-slate-500 hover:bg-slate-50"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <p className="mt-3 text-xs text-slate-600">
              Prioritizes an urgent case immediately after the active consultation, recalculates wait estimates for all waiting tokens, and logs a mandatory audit record.
            </p>

            <form onSubmit={handleEscalateSubmit} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-2 rounded-lg bg-slate-100 p-1">
                <button
                  type="button"
                  onClick={() => setEscalateMode('walkin')}
                  className={`rounded-md px-3 py-1.5 text-xs font-semibold ${
                    escalateMode === 'walkin' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Walk-In Urgent Case
                </button>
                <button
                  type="button"
                  disabled={waitingQueue.length === 0}
                  onClick={() => setEscalateMode('existing')}
                  className={`rounded-md px-3 py-1.5 text-xs font-semibold disabled:opacity-50 ${
                    escalateMode === 'existing' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Promote Waiting Token
                </button>
              </div>

              {escalateMode === 'walkin' ? (
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label htmlFor="emg-name" className="block text-xs font-semibold text-slate-700">
                      Patient Name
                    </label>
                    <input
                      id="emg-name"
                      type="text"
                      required
                      placeholder="Urgent Triage Patient"
                      value={escalateName}
                      onChange={(e) => setEscalateName(e.target.value)}
                      className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label htmlFor="emg-phone" className="block text-xs font-semibold text-slate-700">
                      Contact Number
                    </label>
                    <input
                      id="emg-phone"
                      type="tel"
                      placeholder="+91 98000 00911"
                      value={escalatePhone}
                      onChange={(e) => setEscalatePhone(e.target.value)}
                      className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                </div>
              ) : (
                <div>
                  <label htmlFor="emg-existing" className="block text-xs font-semibold text-slate-700">
                    Select Waiting Token to Prioritize
                  </label>
                  <select
                    id="emg-existing"
                    value={escalateTokenId}
                    onChange={(e) => setEscalateTokenId(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  >
                    {waitingQueue.map((t) => (
                      <option key={t.id} value={t.id}>
                        Token #{t.tokenNumber} — {t.patientName}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label htmlFor="emg-reason" className="block text-xs font-semibold text-slate-700">
                  Clinical Triage Reason (Required for Audit Log)
                </label>
                <input
                  id="emg-reason"
                  type="text"
                  required
                  placeholder="e.g., Acute chest discomfort reported at triage desk"
                  value={escalateReason}
                  onChange={(e) => setEscalateReason(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowEmergencyModal(false)}
                  className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={busy}
                  className="rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700"
                >
                  Confirm Escalation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
