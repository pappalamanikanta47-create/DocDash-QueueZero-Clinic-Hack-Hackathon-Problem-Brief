import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Coffee,
  Siren,
  Stethoscope,
  UserX,
} from 'lucide-react';
import type {DoctorAvailability, TokenStatus} from '../../shared/types';

interface StatusLabelProps {
  status: TokenStatus | DoctorAvailability;
  dark?: boolean;
  delayMinutes?: number;
}

const CONFIG: Record<
  TokenStatus | DoctorAvailability,
  {
    label: string;
    lightCls: string;
    darkCls: string;
    Icon: typeof Clock;
  }
> = {
  waiting: {
    label: 'Waiting',
    lightCls: 'text-slate-700 bg-slate-100 border-slate-200',
    darkCls: 'text-slate-200 bg-slate-800 border-slate-700',
    Icon: Clock,
  },
  in_consultation: {
    label: 'In consultation',
    lightCls: 'text-teal-800 bg-teal-50 border-teal-200',
    darkCls: 'text-teal-200 bg-teal-950/70 border-teal-800',
    Icon: Stethoscope,
  },
  available: {
    label: 'On schedule',
    lightCls: 'text-emerald-800 bg-emerald-50 border-emerald-200',
    darkCls: 'text-emerald-200 bg-emerald-950/70 border-emerald-800',
    Icon: CheckCircle2,
  },
  delayed: {
    label: 'Delayed',
    lightCls: 'text-amber-800 bg-amber-50 border-amber-200',
    darkCls: 'text-amber-200 bg-amber-950/70 border-amber-800',
    Icon: AlertTriangle,
  },
  completed: {
    label: 'Completed',
    lightCls: 'text-emerald-800 bg-emerald-50 border-emerald-200',
    darkCls: 'text-emerald-200 bg-emerald-950/70 border-emerald-800',
    Icon: CheckCircle2,
  },
  absent: {
    label: 'Absent · Holding',
    lightCls: 'text-rose-800 bg-rose-50 border-rose-200',
    darkCls: 'text-rose-200 bg-rose-950/70 border-rose-800',
    Icon: UserX,
  },
  emergency: {
    label: 'Emergency Priority',
    lightCls: 'text-red-800 bg-red-50 border-red-200',
    darkCls: 'text-red-200 bg-red-950/70 border-red-800',
    Icon: Siren,
  },
  on_break: {
    label: 'Between shifts',
    lightCls: 'text-slate-600 bg-slate-100 border-slate-200',
    darkCls: 'text-slate-300 bg-slate-800 border-slate-700',
    Icon: Coffee,
  },
};

export function StatusLabel({status, dark = false, delayMinutes}: StatusLabelProps) {
  const entry = CONFIG[status];
  const Icon = entry.Icon;
  const text =
    status === 'delayed' && delayMinutes && delayMinutes > 0
      ? `Delayed +${delayMinutes}m`
      : entry.label;

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-xs font-medium whitespace-nowrap shrink-0 ${
        dark ? entry.darkCls : entry.lightCls
      }`}
    >
      <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
      <span>{text}</span>
    </span>
  );
}
