import {useState} from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Copy,
  FileText,
  MapPin,
  Navigation,
  RefreshCw,
  Siren,
  UserX,
} from 'lucide-react';
import type {TokenTrackerView} from '../../shared/types';
import {checkInToken} from '../api';
import {StatusLabel} from './StatusLabel';
import type {SyncStatus} from '../useQueueSocket';

interface PatientTrackerCardProps {
  tracker: TokenTrackerView;
  syncStatus: SyncStatus;
  secondsAgo: number;
  onRefresh: () => void;
  onUpdated: (next: TokenTrackerView) => void;
  compact?: boolean;
}

export function PatientTrackerCard({
  tracker,
  syncStatus,
  secondsAgo,
  onRefresh,
  onUpdated,
  compact = false,
}: PatientTrackerCardProps) {
  const {token, clinic, doctor, shift, currentTokenNumber, patientsAhead, estimatedWaitMinutes, arrivalAlert, queueSnapshot} =
    tracker;

  const [checkingIn, setCheckingIn] = useState(false);
  const [checkInFeedback, setCheckInFeedback] = useState<{
    type: 'success' | 'info' | 'error';
    text: string;
    canSimulate?: boolean;
  } | null>(null);
  const [copiedSummary, setCopiedSummary] = useState(false);

  const isWaiting = token.status === 'waiting' || token.status === 'emergency';
  const isInConsultation = token.status === 'in_consultation';
  const isCompleted = token.status === 'completed';
  const isAbsent = token.status === 'absent';

  const submitCoordinates = async (lat: number, lng: number) => {
    setCheckingIn(true);
    setCheckInFeedback(null);
    try {
      const res = await checkInToken(token.id, lat, lng);
      onUpdated(res.tracker);
      if (res.checkedIn) {
        setCheckInFeedback({type: 'success', text: res.message});
      } else {
        setCheckInFeedback({
          type: 'info',
          text: res.message,
          canSimulate: true,
        });
      }
    } catch (err) {
      setCheckInFeedback({type: 'error', text: (err as Error).message});
    } finally {
      setCheckingIn(false);
    }
  };

  const handleProximityCheckIn = () => {
    if (!navigator.geolocation) {
      setCheckInFeedback({
        type: 'info',
        text: 'Browser geolocation is unavailable in this environment.',
        canSimulate: true,
      });
      return;
    }
    setCheckingIn(true);
    setCheckInFeedback(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        void submitCoordinates(pos.coords.latitude, pos.coords.longitude);
      },
      () => {
        setCheckingIn(false);
        setCheckInFeedback({
          type: 'info',
          text: 'Location permission was declined or unavailable. Location is optional and never required for your token.',
          canSimulate: true,
        });
      },
      {enableHighAccuracy: true, timeout: 7000}
    );
  };

  const handleSimulateAtClinic = () => {
    // Small ~110m offset from clinic coordinates to demonstrate real Haversine <= 500m check
    void submitCoordinates(clinic.lat + 0.0007, clinic.lng + 0.0007);
  };

  const handleCopySummary = async () => {
    const text = [
      `${clinic.name} — Visit Summary`,
      `Patient: ${token.patientName} (Token #${token.tokenNumber})`,
      `Clinician: ${doctor.name} (${doctor.specialty})`,
      token.visitNotes ? `Visit Notes: ${token.visitNotes}` : '',
      token.prescriptionSummary ? `Prescription: ${token.prescriptionSummary}` : '',
    ]
      .filter(Boolean)
      .join('\n');
    try {
      await navigator.clipboard.writeText(text);
      setCopiedSummary(true);
      window.setTimeout(() => setCopiedSummary(false), 2000);
    } catch {
      // Ignore clipboard failure
    }
  };

  return (
    <div className="space-y-5">
      {/* Amber 2-tokens-away arrival alert */}
      {arrivalAlert && (
        <div
          role="status"
          aria-live="polite"
          className="flex flex-col gap-2 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3.5 text-amber-950 sm:flex-row sm:items-center sm:justify-between"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-700" aria-hidden="true" />
            <div>
              <p className="font-display text-sm font-bold text-amber-950">
                Please arrive at the clinic now
              </p>
              <p className="text-sm text-amber-900">
                {patientsAhead === 0
                  ? 'You are next to be called into consultation.'
                  : patientsAhead === 1
                    ? `Only 1 patient ahead of you · estimated ${estimatedWaitMinutes} min wait.`
                    : `Only ${patientsAhead} patients ahead of you · estimated ${estimatedWaitMinutes} min wait.`}
              </p>
            </div>
          </div>
          <span className="font-mono text-xs font-semibold tabular-nums text-amber-900 whitespace-nowrap shrink-0">
            {clinic.neighborhood} · {doctor.roomNumber}
          </span>
        </div>
      )}

      {/* In-consultation banner */}
      {isInConsultation && (
        <div
          role="status"
          aria-live="polite"
          className="flex items-center gap-3 rounded-xl border border-teal-300 bg-teal-50 px-4 py-3.5 text-teal-950"
        >
          <CheckCircle2 className="h-5 w-5 shrink-0 text-teal-700" aria-hidden="true" />
          <div>
            <p className="font-display text-sm font-bold">
              It is your turn — please proceed to {doctor.roomNumber}
            </p>
            <p className="text-sm text-teal-900">
              {doctor.name} is ready for Token #{token.tokenNumber}.
            </p>
          </div>
        </div>
      )}

      {/* Absent holding banner */}
      {isAbsent && (
        <div
          role="status"
          className="flex items-start gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3.5 text-rose-950"
        >
          <UserX className="mt-0.5 h-5 w-5 shrink-0 text-rose-700" aria-hidden="true" />
          <div>
            <p className="font-display text-sm font-bold">
              Token #{token.tokenNumber} moved to holding bay (Absent)
            </p>
            <p className="text-sm text-rose-900">
              You were not present when called. Please check in at {clinic.name} reception so staff can restore you to the queue.
            </p>
          </div>
        </div>
      )}

      {/* Primary Token Status Surface */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span>{clinic.name}</span>
              <span aria-hidden="true">·</span>
              <span>{shift.label}</span>
              <span aria-hidden="true">·</span>
              <span>{doctor.roomNumber}</span>
            </div>
            <h2 className="font-display mt-1 text-xl font-bold text-slate-900">
              {doctor.name}
            </h2>
            <p className="text-sm text-slate-600">
              {doctor.specialty} · Patient: <span className="font-medium text-slate-900">{token.patientName}</span>
            </p>
          </div>

          <div className="flex flex-col items-end gap-2">
            <StatusLabel status={token.status} />
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span className="font-mono tabular-nums">
                {syncStatus === 'live' ? 'Live sync' : syncStatus === 'reconnecting' ? 'Reconnecting' : 'Auto-refresh'} · {secondsAgo}s ago
              </span>
              <button
                type="button"
                onClick={onRefresh}
                aria-label="Refresh queue state"
                className="inline-flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              >
                <RefreshCw className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* 4-column tabular metric strip */}
        <div className={`mt-5 grid gap-3 ${compact ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-2 lg:grid-cols-4'}`}>
          <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5">
            <p className="text-xs font-medium text-slate-500">Your Token</p>
            <p className="font-mono mt-1 text-2xl font-bold tabular-nums text-slate-900 sm:text-3xl">
              #{token.tokenNumber}
            </p>
            {token.isEmergency && (
              <p className="mt-1 inline-flex items-center gap-1 text-xs font-medium text-red-700">
                <Siren className="h-3.5 w-3.5" aria-hidden="true" /> Priority Triage
              </p>
            )}
          </div>

          <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5">
            <p className="text-xs font-medium text-slate-500">Now Serving</p>
            <p className="font-mono mt-1 text-2xl font-bold tabular-nums text-teal-700 sm:text-3xl">
              {currentTokenNumber ? `#${currentTokenNumber}` : '—'}
            </p>
            <div className="mt-1">
              <StatusLabel status={doctor.availability} delayMinutes={doctor.delayMinutes} />
            </div>
          </div>

          <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5">
            <p className="text-xs font-medium text-slate-500">Patients Ahead</p>
            <p className="font-mono mt-1 text-2xl font-bold tabular-nums text-slate-900 sm:text-3xl">
              {isWaiting ? patientsAhead : 0}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              {isWaiting
                ? patientsAhead === 0
                  ? 'Next up'
                  : `${patientsAhead} in queue before you`
                : isInConsultation
                  ? 'In room now'
                  : 'Queue finished'}
            </p>
          </div>

          <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5">
            <p className="text-xs font-medium text-slate-500">Estimated Wait</p>
            <p className="font-mono mt-1 text-2xl font-bold tabular-nums text-slate-900 sm:text-3xl">
              {isWaiting ? `~${estimatedWaitMinutes} min` : '0 min'}
            </p>
            <p className="mt-1 font-mono text-xs tabular-nums text-slate-500">
              Pace: ~{doctor.ewmaPaceMin.toFixed(1)}m/visit
              {doctor.delayMinutes > 0 ? ` (+${doctor.delayMinutes}m delay)` : ''}
            </p>
          </div>
        </div>

        {/* Approximate disclaimer */}
        <p className="mt-3 flex items-center gap-1.5 text-xs text-slate-500">
          <Clock className="h-3.5 w-3.5 shrink-0 text-slate-400" aria-hidden="true" />
          <span>
            Wait estimates are approximate based on Dr. {doctor.name.split(' ').slice(-1)[0]}&apos;s rolling EWMA consultation pace and recalculate after every queue update.
          </span>
        </p>

        {/* Privacy-safe live queue strip */}
        {queueSnapshot.length > 0 && (
          <div className="mt-5 border-t border-slate-100 pt-4">
            <p className="text-xs font-medium text-slate-500">
              Live Shift Order (Token numbers only · patient details hidden)
            </p>
            <div className="mt-2.5 flex flex-wrap items-center gap-2">
              {queueSnapshot.map((item) => (
                <div
                  key={item.tokenNumber}
                  className={`flex items-center gap-1.5 rounded-md border px-2.5 py-1 font-mono text-xs font-semibold tabular-nums ${
                    item.isCurrentUser
                      ? 'border-teal-600 bg-teal-600 text-white'
                      : item.status === 'in_consultation'
                        ? 'border-teal-200 bg-teal-50 text-teal-900'
                        : item.isEmergency
                          ? 'border-red-200 bg-red-50 text-red-800'
                          : 'border-slate-200 bg-white text-slate-700'
                  }`}
                >
                  <span>#{item.tokenNumber}</span>
                  {item.status === 'in_consultation' && (
                    <span className="font-sans text-[11px] font-medium">
                      {item.isCurrentUser ? '· You (Now)' : '· Serving'}
                    </span>
                  )}
                  {item.isCurrentUser && item.status !== 'in_consultation' && (
                    <span className="font-sans text-[11px] font-medium">· You</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Stretch Feature: Opt-in Proximity Check-in (within 500m) */}
      {(isWaiting || isInConsultation) && (
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-teal-700 shrink-0" aria-hidden="true" />
                <h3 className="font-display text-sm font-bold text-slate-900">
                  Optional Arrival Check-In (Within 500m)
                </h3>
              </div>
              <p className="text-xs text-slate-600">
                Let clinic reception know you have arrived near {clinic.name}. Location is optional and never required for booking or tracking.
              </p>
            </div>

            {token.checkedInAt ? (
              <div className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-800 whitespace-nowrap shrink-0">
                <ClipboardCheck className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>
                  Arrived at clinic ({token.checkInDistanceM ?? 0}m)
                </span>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleProximityCheckIn}
                disabled={checkingIn}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 disabled:opacity-60 whitespace-nowrap shrink-0"
              >
                <Navigation className="h-3.5 w-3.5 text-teal-700" aria-hidden="true" />
                <span>{checkingIn ? 'Checking GPS...' : 'Verify Arrival & Check In'}</span>
              </button>
            )}
          </div>

          {checkInFeedback && (
            <div
              className={`mt-3 flex flex-col gap-2 rounded-lg border px-3.5 py-2.5 text-xs sm:flex-row sm:items-center sm:justify-between ${
                checkInFeedback.type === 'success'
                  ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                  : checkInFeedback.type === 'error'
                    ? 'border-red-200 bg-red-50 text-red-900'
                    : 'border-slate-200 bg-slate-50 text-slate-700'
              }`}
            >
              <span>{checkInFeedback.text}</span>
              {checkInFeedback.canSimulate && !token.checkedInAt && (
                <button
                  type="button"
                  onClick={handleSimulateAtClinic}
                  className="rounded-md border border-teal-300 bg-white px-2.5 py-1 font-semibold text-teal-800 hover:bg-teal-50 whitespace-nowrap shrink-0"
                >
                  Test Check-In at Clinic Coordinates
                </button>
              )}
            </div>
          )}
        </section>
      )}

      {/* Stretch Feature: Visit Notes & Prescription Summary on completed appointment */}
      {isCompleted && (
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-teal-700" aria-hidden="true" />
              <h3 className="font-display text-base font-bold text-slate-900">
                Visit Notes &amp; Prescription Summary
              </h3>
            </div>
            {(token.visitNotes || token.prescriptionSummary) && (
              <button
                type="button"
                onClick={handleCopySummary}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{copiedSummary ? 'Copied' : 'Copy Summary'}</span>
              </button>
            )}
          </div>

          {token.visitNotes || token.prescriptionSummary ? (
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div>
                <p className="text-xs font-semibold text-slate-500">Clinical Visit Notes</p>
                <p className="mt-1.5 text-sm leading-relaxed text-slate-800">
                  {token.visitNotes || 'No additional consultation notes recorded.'}
                </p>
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-500">Prescription &amp; Care Plan</p>
                <p className="mt-1.5 text-sm leading-relaxed text-slate-800">
                  {token.prescriptionSummary || 'No prescription attached.'}
                </p>
              </div>
            </div>
          ) : (
            <p className="mt-3 text-sm text-slate-600">
              Consultation completed. Your clinician has not attached visit notes or a prescription summary yet—updates appear here automatically once saved.
            </p>
          )}
        </section>
      )}
    </div>
  );
}
