import {useState} from 'react';
import {Link, NavLink, useLocation} from 'react-router-dom';
import {Menu, X} from 'lucide-react';

const NAV_LINKS = [
  {to: '/', label: 'Directory'},
  {to: '/track', label: 'Track Token'},
  {to: '/doctor', label: 'Doctor Console'},
  {to: '/board', label: 'Waiting Board'},
  {to: '/analytics', label: 'Analytics'},
];

export function TopBar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const isBoard = location.pathname.startsWith('/board');

  return (
    <header
      className={`sticky top-0 z-40 border-b transition-colors ${
        isBoard
          ? 'border-slate-800 bg-[#0F172A]/95 text-slate-100 backdrop-blur'
          : 'border-slate-200 bg-white/95 text-slate-900 backdrop-blur'
      }`}
    >
      <div className="mx-auto flex max-w-[1360px] items-center justify-between gap-8 px-4 py-3.5 sm:px-6 lg:px-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <Link
          to="/"
          className={`font-display text-lg font-bold tracking-tight whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-600 ${
            isBoard ? 'text-white' : 'text-slate-900'
          }`}
        >
          DocDash: QueueZero
        </Link>

        {/* Zone 2: 5 concise single-line text links */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-6">
          {NAV_LINKS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({isActive}) =>
                `text-sm font-medium whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-teal-600 ${
                  isActive
                    ? isBoard
                      ? 'border-teal-400 text-white'
                      : 'border-teal-600 text-teal-700'
                    : isBoard
                      ? 'border-transparent text-slate-300 hover:text-white hover:border-slate-600'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* Zone 3: 1 primary action + mobile menu button */}
        <div className="flex items-center gap-3 shrink-0">
          <Link
            to="/demo"
            className={`hidden sm:inline-flex items-center justify-center rounded-lg px-4 py-2 text-sm font-semibold whitespace-nowrap shrink-0 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-600 ${
              location.pathname === '/demo'
                ? 'bg-teal-700 text-white'
                : isBoard
                  ? 'bg-teal-500 text-slate-950 hover:bg-teal-400'
                  : 'bg-teal-600 text-white hover:bg-teal-700'
            }`}
          >
            Live Demo
          </Link>

          <button
            type="button"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((prev) => !prev)}
            className={`inline-flex h-10 w-10 items-center justify-center rounded-lg border md:hidden ${
              isBoard
                ? 'border-slate-700 text-slate-200 hover:bg-slate-800'
                : 'border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div
          className={`border-t px-4 py-3 md:hidden ${
            isBoard ? 'border-slate-800 bg-[#0F172A]' : 'border-slate-200 bg-white'
          }`}
        >
          <nav aria-label="Mobile navigation" className="flex flex-col gap-1">
            {NAV_LINKS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                onClick={() => setMobileOpen(false)}
                className={({isActive}) =>
                  `rounded-lg px-3 py-2.5 text-sm font-medium ${
                    isActive
                      ? isBoard
                        ? 'bg-slate-800 text-teal-300'
                        : 'bg-teal-50 text-teal-800'
                      : isBoard
                        ? 'text-slate-300 hover:bg-slate-800/70'
                        : 'text-slate-700 hover:bg-slate-100'
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
            <Link
              to="/demo"
              onClick={() => setMobileOpen(false)}
              className="mt-2 inline-flex items-center justify-center rounded-lg bg-teal-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-teal-700"
            >
              Live Demo
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
