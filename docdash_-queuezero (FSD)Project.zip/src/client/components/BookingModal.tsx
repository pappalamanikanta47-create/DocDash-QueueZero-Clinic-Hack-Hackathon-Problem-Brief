import {useState} from 'react';
import {X, CalendarClock, AlertCircle} from 'lucide-react';
import type {DirectoryDoctor, TokenTrackerView} from '../../shared/types';
import {bookToken} from '../api';

interface BookingModalProps {
  doctor: DirectoryDoctor;
  initialShiftId?: string;
  onClose: () => void;
  onBooked: (tracker: TokenTrackerView) => void;
}

export function BookingModal({
  doctor,
  initialShiftId,
  onClose,
  onBooked,
}: BookingModalProps) {
  const defaultShift =
    doctor.shifts.find((s) => s.id === initialShiftId) ?? doctor.shifts[0];
  const [shiftId, setShiftId] = useState(defaultShift?.id ?? '');
  const [patientName, setPatientName] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedShift = doctor.shifts.find((s) => s.id === shiftId) ?? defaultShift;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim() || !contactNumber.trim()) {
      setError('Please enter both your full name and mobile contact number.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const tracker = await bookToken({
        shiftId,
        patientName: patientName.trim(),
        contactNumber: contactNumber.trim(),
      });
      // Save recent token for convenience in Track Token view
      try {
        localStorage.setItem('queuezero_last_token_id', tracker.token.id);
      } catch {
        // Ignore storage restrictions
      }
      onBooked(tracker);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
    >
      <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-6 shadow-xl">
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <p className="text-xs font-medium text-teal-700">Virtual Token Booking</p>
            <h2 id="booking-modal-title" className="font-display mt-0.5 text-xl font-bold text-slate-900">
              {doctor.name}
            </h2>
            <p className="mt-1 text-sm text-slate-600">
              {doctor.specialty} · {doctor.clinic.name} · ₹{doctor.consultationFee}
            </p>
          </div>
          <button
            type="button"
            aria-label="Close booking dialog"
            onClick={onClose}
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-5">
          <div>
            <label className="block text-sm font-medium text-slate-800">
              Consultation Shift
            </label>
            <div className="mt-2 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {doctor.shifts.map((shift) => {
                const active = shift.id === shiftId;
                return (
                  <button
                    key={shift.id}
                    type="button"
                    onClick={() => setShiftId(shift.id)}
                    className={`rounded-lg border p-3 text-left transition-colors ${
                      active
                        ? 'border-teal-600 bg-teal-50/70 text-slate-900'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-semibold capitalize">
                        {shift.period} Shift
                      </span>
                      <span className="font-mono text-xs tabular-nums text-teal-700">
                        Next #{shift.lastTokenNumber + 1}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-slate-500">{shift.label}</p>
                    <p className="mt-1.5 font-mono text-xs tabular-nums text-slate-700">
                      {shift.waitingCount} waiting · ~{shift.estimatedNextWaitMin} min est.
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {selectedShift && (
            <div className="flex items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm">
              <div className="flex items-center gap-2 text-slate-700">
                <CalendarClock className="h-4 w-4 text-teal-700 shrink-0" aria-hidden="true" />
                <span>
                  {selectedShift.currentTokenNumber
                    ? `Currently serving #${selectedShift.currentTokenNumber}`
                    : 'Queue ready to start'}
                </span>
              </div>
              <span className="font-mono text-xs font-semibold tabular-nums text-slate-900">
                Est. ~{selectedShift.estimatedNextWaitMin} min
              </span>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label htmlFor="booking-patient-name" className="block text-sm font-medium text-slate-800">
                Patient Full Name
              </label>
              <input
                id="booking-patient-name"
                type="text"
                required
                placeholder="e.g., Patient A"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-600 focus:outline-none focus:ring-2 focus:ring-teal-600/20"
              />
            </div>

            <div>
              <label htmlFor="booking-contact-number" className="block text-sm font-medium text-slate-800">
                Mobile Contact Number
              </label>
              <input
                id="booking-contact-number"
                type="tel"
                required
                placeholder="e.g., +91 98450 11223"
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-600 focus:outline-none focus:ring-2 focus:ring-teal-600/20"
              />
            </div>
          </div>

          {error && (
            <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-800">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex items-center justify-between gap-3 border-t border-slate-100 pt-4">
            <p className="text-xs text-slate-500">
              Wait times are approximate and adjust live with consultation pace.
            </p>
            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="rounded-lg bg-teal-600 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-700 disabled:opacity-60 whitespace-nowrap shrink-0"
              >
                {submitting ? 'Issuing Token...' : 'Confirm & Get Token'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
