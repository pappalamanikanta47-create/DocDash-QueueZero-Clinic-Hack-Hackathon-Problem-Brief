import type {
  AuditEntry,
  Clinic,
  DirectoryDoctor,
  DoctorConsoleData,
  HeatmapCell,
  PublicBoardEntry,
  QueueToken,
  TokenTrackerView,
} from '../shared/types';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
    },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as {error?: string}).error || `Request failed (${res.status})`);
  }
  return data as T;
}

export function fetchDirectory(): Promise<{clinics: Clinic[]; doctors: DirectoryDoctor[]}> {
  return request('/api/directory');
}

export function bookToken(payload: {
  shiftId: string;
  patientName: string;
  contactNumber: string;
}): Promise<TokenTrackerView> {
  return request('/api/tokens/book', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function fetchTokenTracker(tokenId: string): Promise<TokenTrackerView> {
  return request(`/api/tokens/${encodeURIComponent(tokenId)}`);
}

export function lookupToken(shiftId: string, tokenNumber: number): Promise<TokenTrackerView> {
  return request(
    `/api/tokens/lookup?shiftId=${encodeURIComponent(shiftId)}&tokenNumber=${tokenNumber}`
  );
}

export function checkInToken(
  tokenId: string,
  lat: number,
  lng: number
): Promise<{
  checkedIn: boolean;
  distanceMeters: number;
  message: string;
  tracker: TokenTrackerView;
}> {
  return request(`/api/tokens/${encodeURIComponent(tokenId)}/checkin`, {
    method: 'POST',
    body: JSON.stringify({lat, lng}),
  });
}

export function updateTokenNotes(
  tokenId: string,
  visitNotes: string,
  prescriptionSummary: string
): Promise<QueueToken> {
  return request(`/api/tokens/${encodeURIComponent(tokenId)}/notes`, {
    method: 'PATCH',
    body: JSON.stringify({visitNotes, prescriptionSummary}),
  });
}

export function fetchDoctorConsole(doctorId: string, shiftId?: string): Promise<DoctorConsoleData> {
  const q = shiftId ? `?shiftId=${encodeURIComponent(shiftId)}` : '';
  return request(`/api/doctor/${encodeURIComponent(doctorId)}${q}`);
}

export function doctorCallNext(
  doctorId: string,
  shiftId: string,
  durationOverrideMin?: number
): Promise<{console: DoctorConsoleData; message: string}> {
  return request(`/api/doctor/${encodeURIComponent(doctorId)}/call-next`, {
    method: 'POST',
    body: JSON.stringify({shiftId, durationOverrideMin}),
  });
}

export function doctorCompleteCurrent(
  doctorId: string,
  payload: {
    shiftId: string;
    durationOverrideMin?: number;
    visitNotes?: string;
    prescriptionSummary?: string;
  }
): Promise<{console: DoctorConsoleData; completedTokenId: string; message: string}> {
  return request(`/api/doctor/${encodeURIComponent(doctorId)}/complete`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function doctorAddDelay(
  doctorId: string,
  shiftId: string,
  minutes: number,
  reason?: string
): Promise<{console: DoctorConsoleData; message: string}> {
  return request(`/api/doctor/${encodeURIComponent(doctorId)}/delay`, {
    method: 'POST',
    body: JSON.stringify({shiftId, minutes, reason}),
  });
}

export function doctorMarkAbsent(
  doctorId: string,
  shiftId: string,
  tokenId?: string
): Promise<{console: DoctorConsoleData; message: string}> {
  return request(`/api/doctor/${encodeURIComponent(doctorId)}/absent`, {
    method: 'POST',
    body: JSON.stringify({shiftId, tokenId}),
  });
}

export function restoreAbsentToken(
  tokenId: string
): Promise<{console: DoctorConsoleData; message: string}> {
  return request(`/api/tokens/${encodeURIComponent(tokenId)}/restore`, {
    method: 'POST',
  });
}

export function doctorEscalateEmergency(
  doctorId: string,
  payload: {
    shiftId: string;
    tokenId?: string;
    patientName?: string;
    contactNumber?: string;
    reason: string;
    staffActor?: string;
  }
): Promise<{console: DoctorConsoleData; token: QueueToken; message: string}> {
  return request(`/api/doctor/${encodeURIComponent(doctorId)}/escalate`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function fetchPublicBoard(
  clinicId?: string
): Promise<{entries: PublicBoardEntry[]; updatedAt: string}> {
  const q = clinicId && clinicId !== 'all' ? `?clinicId=${encodeURIComponent(clinicId)}` : '';
  return request(`/api/board${q}`);
}

export function fetchAnalytics(
  clinicId = 'all'
): Promise<{cells: HeatmapCell[]; auditLogs: AuditEntry[]}> {
  return request(`/api/analytics/heatmap?clinicId=${encodeURIComponent(clinicId)}`);
}

export function resetDemoState(): Promise<{ok: boolean; message: string}> {
  return request('/api/demo/reset', {method: 'POST'});
}
