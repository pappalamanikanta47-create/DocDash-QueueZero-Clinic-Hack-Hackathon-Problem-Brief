import {useEffect, useRef, useState} from 'react';
import type {WsEvent} from '../shared/types';

export type SyncStatus = 'live' | 'reconnecting' | 'polling';

export function useQueueSocket(onEvent: (event: WsEvent) => void) {
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('reconnecting');
  const [lastSyncAt, setLastSyncAt] = useState<number>(() => Date.now());
  const [secondsAgo, setSecondsAgo] = useState<number>(0);
  const onEventRef = useRef(onEvent);

  useEffect(() => {
    onEventRef.current = onEvent;
  }, [onEvent]);

  const markSynced = () => {
    setLastSyncAt(Date.now());
    setSecondsAgo(0);
  };

  useEffect(() => {
    const ticker = window.setInterval(() => {
      setSecondsAgo(Math.max(0, Math.floor((Date.now() - lastSyncAt) / 1000)));
    }, 1000);
    return () => window.clearInterval(ticker);
  }, [lastSyncAt]);

  useEffect(() => {
    let ws: WebSocket | null = null;
    let reconnectTimer: number | null = null;
    let disposed = false;
    let attempts = 0;

    const connect = () => {
      if (disposed) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const url = `${protocol}//${window.location.host}/ws`;

      try {
        ws = new WebSocket(url);
      } catch {
        setSyncStatus('polling');
        return;
      }

      ws.onopen = () => {
        attempts = 0;
        setSyncStatus('live');
        setLastSyncAt(Date.now());
      };

      ws.onmessage = (msg) => {
        try {
          const parsed = JSON.parse(msg.data) as WsEvent;
          setLastSyncAt(Date.now());
          if (parsed.type !== 'connected') {
            onEventRef.current(parsed);
          }
        } catch {
          // Ignore malformed frame
        }
      };

      ws.onclose = () => {
        if (disposed) return;
        attempts += 1;
        setSyncStatus(attempts > 3 ? 'polling' : 'reconnecting');
        const delay = Math.min(8000, 1000 * Math.pow(1.5, attempts));
        reconnectTimer = window.setTimeout(connect, delay);
      };

      ws.onerror = () => {
        ws?.close();
      };
    };

    connect();

    // Lightweight safety poll every 15s in case a proxy buffers WS frames
    const fallbackPoll = window.setInterval(() => {
      onEventRef.current({
        type: 'queue:updated',
        timestamp: new Date().toISOString(),
      });
      setLastSyncAt(Date.now());
    }, 15000);

    return () => {
      disposed = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      window.clearInterval(fallbackPoll);
      ws?.close();
    };
  }, []);

  return {syncStatus, secondsAgo, markSynced};
}
