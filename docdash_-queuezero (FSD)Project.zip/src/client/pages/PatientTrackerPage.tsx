import {useCallback, useEffect, useState} from 'react';
import {Link, useNavigate, useParams} from 'react-router-dom';
import {ArrowLeft, Search, Ticket} from 'lucide-react';
import type {DirectoryDoctor, TokenTrackerView} from '../../shared/types';
import {fetchDirectory, fetchTokenTracker, lookupToken} from '../api';
import {useQueueSocket} from '../useQueueSocket';
import {PatientTrackerCard} from '../components/PatientTrackerCard';

export function PatientTrackerPage() {
  const {tokenId} = useParams<{tokenId?: string}>();
  const navigate = useNavigate();

  const [tracker, setTracker] = useState<TokenTrackerView | null>(null);
  const [loading, setLoading] = useState(Boolean(tokenId));
  const [error, setError] = useState<string | null>(null);

  // Lookup state when no :tokenId is in URL
  const [doctors, setDoctors] = useState<DirectoryDoctor[]>([]);
  const [selectedShiftId, setSelectedShiftId] = useState('shift-mehta-morning');
  const [tokenNumberInput, setTokenNumberInput] = useState('12');
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [lastBookedId, setLastBookedId] = useState<string | null>(null);

  useEffect(() => {
    try {
      setLastBookedId(localStorage.getItem('queuezero_last_token_id'));
    } catch {
      // Ignore
    }
  }, []);

  const loadTracker = useCallback(async () => {
    if (!tokenId) return;
    try {
      const data = await fetchTokenTracker(tokenId);
      setTracker(data);
      setError(null);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [tokenId]);

  useEffect(() => {
    if (tokenId) {
      setLoading(true);
      void loadTracker();
    } else {
      setTracker(null);
      setLoading(false);
      void fetchDirectory()
        .then((res) => setDoctors(res.doctors))
        .catch(() => {});
    }
  }, [tokenId, loadTracker]);

  const {syncStatus, secondsAgo, markSynced} = useQueueSocket((event) => {
    if (!tokenId) return;
    if (!tracker || !event.shiftId || event.shiftId === tracker.shift.id || event.type === 'queue:reset') {
      void loadTracker().then(markSynced);
    }
  });

  const handleLookupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLookupError(null);
    try {
      const found = await lookupToken(selectedShiftId, Number(tokenNumberInput));
      navigate(`/track/${found.token.id}`);
    } catch (err) {
      setLookupError((err as Error).message);
    }
  };

  if (!tokenId) {
    return (
      <main className="mx-auto max-w-3xl space-y-6 px-4 py-10 sm:px-6">
        <div>
          <p className="text-xs font-semibold text-teal-700">Live Patient Queue Tracker</p>
          <h1 className="font-display mt-1 text-2xl font-bold text-slate-900 sm:text-3xl">
            Find and track your consultation token
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            Enter your doctor&apos;s shift and token number, or resume a recently booked consultation.
          </p>
        </div>

        {lastBookedId && (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-teal-200 bg-teal-50/70 p-4">
            <div className="flex items-center gap-3">
              <Ticket className="h-5 w-5 text-teal-700 shrink-0" aria-hidden="true" />
              <div>
                <p className="text-sm font-bold text-slate-900">Your recent booking is active</p>
                <p className="text-xs text-slate-600">Jump back into your live queue status.</p>
              </div>
            </div>
            <Link
              to={`/track/${lastBookedId}`}
              className="rounded-lg bg-teal-600 px-4 py-2 text-xs font-semibold text-white hover:bg-teal-700 whitespace-nowrap shrink-0"
            >
              Open My Token
            </Link>
          </div>
        )}

        <form
          onSubmit={handleLookupSubmit}
          className="space-y-4 rounded-xl border border-slate-200 bg-white p-6"
        >
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="sm:col-span-2">
              <label htmlFor="lookup-shift" className="block text-xs font-semibold text-slate-700">
                Doctor &amp; Consultation Shift
              </label>
              <select
                id="lookup-shift"
                value={selectedShiftId}
                onChange={(e) => setSelectedShiftId(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900"
              >
                {doctors.map((doc) =>
                  doc.shifts.map((s) => (
                    <option key={s.id} value={s.id}>
                      {doc.name} ({doc.specialty}) — {s.period}
                    </option>
                  ))
                )}
              </select>
            </div>

            <div>
              <label htmlFor="lookup-number" className="block text-xs font-semibold text-slate-700">
                Token Number
              </label>
              <input
                id="lookup-number"
                type="number"
                min={1}
                required
                value={tokenNumberInput}
                onChange={(e) => setTokenNumberInput(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm tabular-nums text-slate-900"
              />
            </div>
          </div>

          {lookupError && (
            <p className="text-sm font-medium text-red-700">{lookupError}</p>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span>Quick jump:</span>
              <Link
                to="/track/tok-mehta-m-13"
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 font-medium text-slate-700 hover:bg-slate-100"
              >
                Dr. Mehta #13
              </Link>
              <Link
                to="/track/tok-nair-m-6"
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 font-medium text-slate-700 hover:bg-slate-100"
              >
                Dr. Nair #6
              </Link>
              <Link
                to="/track/tok-mehta-m-10"
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 font-medium text-slate-700 hover:bg-slate-100"
              >
                Completed Sample #10
              </Link>
            </div>

            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-lg bg-teal-600 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-700"
            >
              <Search className="h-4 w-4" aria-hidden="true" />
              <span>Track Token</span>
            </button>
          </div>
        </form>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-4xl space-y-6 px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-slate-900"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>Back to Directory</span>
        </Link>

        <Link
          to="/track"
          className="text-xs font-semibold text-teal-700 hover:text-teal-800"
        >
          Track a different token
        </Link>
      </div>

      {loading ? (
        <div className="h-72 animate-pulse rounded-xl border border-slate-200 bg-white p-6" />
      ) : error || !tracker ? (
        <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-sm text-red-900">
          <p className="font-semibold">Unable to load token details</p>
          <p className="mt-1">{error || 'Token not found.'}</p>
          <Link
            to="/"
            className="mt-4 inline-flex rounded-lg bg-teal-600 px-4 py-2 text-xs font-semibold text-white hover:bg-teal-700"
          >
            Book a New Token
          </Link>
        </div>
      ) : (
        <PatientTrackerCard
          tracker={tracker}
          syncStatus={syncStatus}
          secondsAgo={secondsAgo}
          onRefresh={() => void loadTracker().then(markSynced)}
          onUpdated={setTracker}
        />
      )}
    </main>
  );
}
