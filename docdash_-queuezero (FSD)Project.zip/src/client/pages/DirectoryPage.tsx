import {useCallback, useEffect, useMemo, useState} from 'react';
import {Link, useNavigate} from 'react-router-dom';
import {
  ArrowRight,
  Building2,
  Clock,
  MapPin,
  Search,
  Sparkles,
} from 'lucide-react';
import type {Clinic, DirectoryDoctor, Specialty, TokenTrackerView} from '../../shared/types';
import {fetchDirectory} from '../api';
import {useQueueSocket} from '../useQueueSocket';
import {StatusLabel} from '../components/StatusLabel';
import {BookingModal} from '../components/BookingModal';

const SPECIALTIES: Array<'All' | Specialty> = [
  'All',
  'Cardiology',
  'General Medicine',
  'Pediatrics',
  'Orthopedics',
];

export function DirectoryPage() {
  const navigate = useNavigate();
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [doctors, setDoctors] = useState<DirectoryDoctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [selectedClinicId, setSelectedClinicId] = useState<string>('all');
  const [selectedSpecialty, setSelectedSpecialty] = useState<'All' | Specialty>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedShiftMap, setSelectedShiftMap] = useState<Record<string, string>>({});
  const [bookingTarget, setBookingTarget] = useState<{
    doctor: DirectoryDoctor;
    shiftId: string;
  } | null>(null);

  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [failedClinicImgs, setFailedClinicImgs] = useState<Record<string, boolean>>({});

  const loadDirectory = useCallback(async () => {
    try {
      const data = await fetchDirectory();
      setClinics(data.clinics);
      setDoctors(data.doctors);
      setError(null);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadDirectory();
  }, [loadDirectory]);

  const {syncStatus, secondsAgo} = useQueueSocket(() => {
    void loadDirectory();
  });

  const filteredDoctors = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return doctors.filter((doc) => {
      if (selectedClinicId !== 'all' && doc.clinicId !== selectedClinicId) return false;
      if (selectedSpecialty !== 'All' && doc.specialty !== selectedSpecialty) return false;
      if (q) {
        const hay = `${doc.name} ${doc.specialty} ${doc.clinic.name} ${doc.clinic.neighborhood}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [doctors, selectedClinicId, selectedSpecialty, searchQuery]);

  const handleBooked = (tracker: TokenTrackerView) => {
    setBookingTarget(null);
    navigate(`/track/${tracker.token.id}`);
  };

  return (
    <main className="mx-auto max-w-[1360px] space-y-10 px-4 py-8 sm:px-6 lg:px-8">
      {/* Hero Split */}
      <section className="grid grid-cols-1 items-stretch gap-6 lg:grid-cols-12">
        <div className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6 sm:p-8 lg:col-span-7">
          <div>
            <p className="text-xs font-semibold text-teal-700">
              Bengaluru Outpatient Network · 4 Clinics · Live Queue Sync
            </p>
            <h1 className="font-display mt-3 max-w-2xl text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl [text-wrap:balance]">
              Know your exact place in line before you leave home.
            </h1>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-slate-600">
              Browse specialists across four city clinics, book a numbered consultation token for a morning or evening shift, and follow live wait estimates adapted to your doctor&apos;s pace.
            </p>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link
              to="/demo"
              className="inline-flex items-center gap-2 rounded-lg bg-teal-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-teal-700 whitespace-nowrap shrink-0"
            >
              <span>Run Dr. Mehta Live Demo</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
            <Link
              to="/track"
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              <span>Track an Existing Token</span>
            </Link>
            <span className="font-mono text-xs tabular-nums text-slate-500">
              {syncStatus === 'live' ? 'Live WebSocket' : 'Syncing'} · {secondsAgo}s ago
            </span>
          </div>
        </div>

        <div className="overflow-hidden rounded-xl border border-slate-200 bg-slate-100 lg:col-span-5">
          {!heroImgFailed ? (
            <img
              src="/src/assets/images/clinic_hero_lounge_1794931719744.jpg"
              alt="Sunlit outpatient clinic reception and waiting lounge"
              referrerPolicy="no-referrer"
              onError={() => setHeroImgFailed(true)}
              className="h-64 w-full object-cover lg:h-full"
            />
          ) : (
            <div className="flex h-64 w-full flex-col items-center justify-center bg-gradient-to-br from-teal-50 to-slate-100 p-6 text-center lg:h-full">
              <Building2 className="h-10 w-10 text-teal-700" aria-hidden="true" />
              <p className="font-display mt-3 text-base font-bold text-slate-800">
                QueueZero Clinic Network
              </p>
              <p className="mt-1 text-xs text-slate-500">Calm outpatient waiting experience</p>
            </div>
          )}
        </div>
      </section>

      {/* 4-Column Clinic Strip below Hero */}
      <section aria-labelledby="clinics-heading" className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 id="clinics-heading" className="font-display text-lg font-bold text-slate-900">
              City Clinics
            </h2>
            <p className="text-sm text-slate-600">
              Select a branch to filter doctors, or view all four clinics together.
            </p>
          </div>
          {selectedClinicId !== 'all' && (
            <button
              type="button"
              onClick={() => setSelectedClinicId('all')}
              className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Show All 4 Clinics
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {clinics.map((clinic) => {
            const active = selectedClinicId === clinic.id;
            const clinicDocCount = doctors.filter((d) => d.clinicId === clinic.id).length;
            return (
              <button
                key={clinic.id}
                type="button"
                onClick={() =>
                  setSelectedClinicId((prev) => (prev === clinic.id ? 'all' : clinic.id))
                }
                className={`group flex flex-col overflow-hidden rounded-xl border text-left transition-colors ${
                  active
                    ? 'border-teal-600 bg-teal-50/40'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100">
                  {!failedClinicImgs[clinic.id] ? (
                    <img
                      src={clinic.imagePath}
                      alt={clinic.name}
                      referrerPolicy="no-referrer"
                      onError={() =>
                        setFailedClinicImgs((prev) => ({...prev, [clinic.id]: true}))
                      }
                      className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-[1.02]"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-slate-100 text-slate-400">
                      <Building2 className="h-8 w-8" aria-hidden="true" />
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-teal-700">
                      {clinic.neighborhood}
                    </span>
                    <span className="font-mono text-xs tabular-nums text-slate-500">
                      {clinicDocCount} doctors
                    </span>
                  </div>
                  <h3 className="font-display mt-1 text-sm font-bold text-slate-900">
                    {clinic.name}
                  </h3>
                  <p className="mt-1 flex items-center gap-1 text-xs text-slate-500">
                    <MapPin className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                    <span className="truncate">{clinic.address}</span>
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Doctor Filter Bar + Directory */}
      <section aria-labelledby="doctors-heading" className="space-y-5">
        <div className="flex flex-col gap-4 border-b border-slate-200 pb-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 id="doctors-heading" className="font-display text-xl font-bold text-slate-900">
              Available Specialists ({filteredDoctors.length})
            </h2>
            <p className="text-sm text-slate-600">
              Choose an active morning or evening consultation shift to book a virtual token.
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="relative">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                aria-hidden="true"
              />
              <input
                type="search"
                aria-label="Search doctors or clinics"
                placeholder="Search doctor or clinic..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white py-2 pl-9 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-600 focus:outline-none sm:w-64"
              />
            </div>

            <div
              role="tablist"
              aria-label="Filter by specialty"
              className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1"
            >
              {SPECIALTIES.map((spec) => (
                <button
                  key={spec}
                  type="button"
                  role="tab"
                  aria-selected={selectedSpecialty === spec}
                  onClick={() => setSelectedSpecialty(spec)}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    selectedSpecialty === spec
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {spec}
                </button>
              ))}
            </div>
          </div>
        </div>

        {error && (
          <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-900">
            Unable to load directory: {error}
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="h-60 animate-pulse rounded-xl border border-slate-200 bg-white p-6"
              />
            ))}
          </div>
        ) : filteredDoctors.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 bg-white p-10 text-center">
            <p className="font-display text-base font-bold text-slate-900">
              No doctors match your current filters
            </p>
            <p className="mt-1 text-sm text-slate-600">
              Try clearing your specialty or clinic selection to view all 8 specialists.
            </p>
            <button
              type="button"
              onClick={() => {
                setSelectedClinicId('all');
                setSelectedSpecialty('All');
                setSearchQuery('');
              }}
              className="mt-4 rounded-lg bg-teal-600 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-700"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            {filteredDoctors.map((doc) => {
              const activeShiftId = selectedShiftMap[doc.id] ?? doc.shifts[0]?.id;
              const activeShift =
                doc.shifts.find((s) => s.id === activeShiftId) ?? doc.shifts[0];

              return (
                <article
                  key={doc.id}
                  className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6 transition-colors hover:border-slate-300"
                >
                  <div>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3.5">
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 font-display text-sm font-bold text-slate-800">
                          {doc.initials}
                        </div>
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="font-display text-lg font-bold text-slate-900">
                              {doc.name}
                            </h3>
                            {doc.id === 'doc-mehta' && (
                              <span className="inline-flex items-center gap-1 text-xs font-semibold text-teal-700">
                                <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                                Featured Demo
                              </span>
                            )}
                          </div>
                          <p className="mt-0.5 text-xs text-slate-600">
                            {doc.specialty} · {doc.clinic.name} · {doc.roomNumber}
                          </p>
                        </div>
                      </div>

                      <StatusLabel status={doc.availability} delayMinutes={doc.delayMinutes} />
                    </div>

                    <p className="mt-3 text-sm leading-relaxed text-slate-600">{doc.bio}</p>

                    <div className="mt-4 flex flex-wrap items-center gap-4 border-t border-slate-100 pt-3 text-xs text-slate-600">
                      <span>
                        Consultation fee:{' '}
                        <strong className="font-mono tabular-nums text-slate-900">
                          ₹{doc.consultationFee}
                        </strong>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5 text-slate-400" aria-hidden="true" />
                        Avg pace:{' '}
                        <strong className="font-mono tabular-nums text-slate-900">
                          {doc.ewmaPaceMin.toFixed(1)} min
                        </strong>
                      </span>
                    </div>
                  </div>

                  {/* Shift picker & Book CTA */}
                  <div className="mt-5 flex flex-col gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="space-y-1.5">
                      <div className="inline-flex items-center gap-1 rounded-lg bg-slate-100 p-1">
                        {doc.shifts.map((shift) => (
                          <button
                            key={shift.id}
                            type="button"
                            onClick={() =>
                              setSelectedShiftMap((prev) => ({...prev, [doc.id]: shift.id}))
                            }
                            className={`rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors whitespace-nowrap shrink-0 ${
                              shift.id === activeShift?.id
                                ? 'bg-white text-slate-900 shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            {shift.period}
                          </button>
                        ))}
                      </div>
                      {activeShift && (
                        <p className="font-mono text-xs tabular-nums text-slate-600">
                          {activeShift.currentTokenNumber
                            ? `Now #${activeShift.currentTokenNumber}`
                            : 'Ready'}{' '}
                          · {activeShift.waitingCount} waiting · ~{activeShift.estimatedNextWaitMin} min est.
                        </p>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        activeShift && setBookingTarget({doctor: doc, shiftId: activeShift.id})
                      }
                      className="inline-flex items-center justify-center rounded-lg bg-teal-600 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-700 whitespace-nowrap shrink-0"
                    >
                      Book Token #{activeShift ? activeShift.lastTokenNumber + 1 : 1}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {bookingTarget && (
        <BookingModal
          doctor={bookingTarget.doctor}
          initialShiftId={bookingTarget.shiftId}
          onClose={() => setBookingTarget(null)}
          onBooked={handleBooked}
        />
      )}
    </main>
  );
}
