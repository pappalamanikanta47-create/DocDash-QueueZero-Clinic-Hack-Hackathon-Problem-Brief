import {useCallback, useEffect, useState} from 'react';
import {AlertTriangle, Maximize2, Minimize2, ShieldCheck, Siren} from 'lucide-react';
import type {Clinic, PublicBoardEntry} from '../../shared/types';
import {fetchDirectory, fetchPublicBoard} from '../api';
import {useQueueSocket} from '../useQueueSocket';
import {StatusLabel} from '../components/StatusLabel';

export function WaitingBoardPage() {
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [selectedClinicId, setSelectedClinicId] = useState<string>('all');
  const [entries, setEntries] = useState<PublicBoardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [clock, setClock] = useState(() => new Date());
  const [isFullscreen, setIsFullscreen] = useState(false);

  const loadBoard = useCallback(async () => {
    try {
      const res = await fetchPublicBoard(selectedClinicId);
      setEntries(res.entries);
    } finally {
      setLoading(false);
    }
  }, [selectedClinicId]);

  useEffect(() => {
    void fetchDirectory()
      .then((d) => setClinics(d.clinics))
      .catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    void loadBoard();
  }, [loadBoard]);

  useEffect(() => {
    const id = window.setInterval(() => setClock(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const {syncStatus, secondsAgo, markSynced} = useQueueSocket(() => {
    void loadBoard().then(markSynced);
  });

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch {
      // Ignore fullscreen denial inside iframe
    }
  };

  return (
    <div className="min-h-[calc(100vh-61px)] bg-[#0F172A] text-slate-100">
      <main className="mx-auto max-w-[1400px] space-y-6 px-4 py-8 sm:px-6 lg:px-8">
        {/* Kiosk Header */}
        <div className="flex flex-col gap-4 border-b border-slate-800 pb-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-teal-400">
              <ShieldCheck className="h-4 w-4" aria-hidden="true" />
              <span>Public Waiting-Room Display · Privacy Mode (No Patient Names)</span>
            </div>
            <h1 className="font-display mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Live Consultation Board
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-900 p-1 border border-slate-800">
              <button
                type="button"
                onClick={() => setSelectedClinicId('all')}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  selectedClinicId === 'all'
                    ? 'bg-slate-700 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                All Clinics
              </button>
              {clinics.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setSelectedClinicId(c.id)}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    selectedClinicId === c.id
                      ? 'bg-slate-700 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {c.neighborhood}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="font-mono text-xl font-bold tabular-nums text-white">
                  {clock.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
                </p>
                <p className="font-mono text-xs tabular-nums text-slate-400">
                  {syncStatus === 'live' ? 'Live sync' : 'Refreshing'} · {secondsAgo}s ago
                </p>
              </div>
              <button
                type="button"
                onClick={toggleFullscreen}
                aria-label={isFullscreen ? 'Exit fullscreen board' : 'Enter fullscreen board'}
                className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700"
              >
                {isFullscreen ? (
                  <Minimize2 className="h-4 w-4" />
                ) : (
                  <Maximize2 className="h-4 w-4" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Distance-Readable Kiosk Cards */}
        {loading ? (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="h-52 animate-pulse rounded-xl border border-slate-800 bg-slate-900"
              />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            {entries.map((entry) => (
              <article
                key={entry.doctorId}
                className="flex flex-col justify-between rounded-xl border border-slate-800 bg-[#1E293B] p-6"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-medium text-slate-400">
                      {entry.clinicName} · {entry.roomNumber}
                    </p>
                    <h2 className="font-display mt-1 text-2xl font-bold text-white">
                      {entry.doctorName}
                    </h2>
                    <p className="text-sm text-slate-300">
                      {entry.specialty} · {entry.shiftLabel}
                    </p>
                  </div>
                  <StatusLabel
                    status={entry.availability}
                    dark
                    delayMinutes={entry.delayMinutes}
                  />
                </div>

                {/* Big Token Displays */}
                <div className="mt-6 grid grid-cols-3 gap-3 rounded-xl border border-slate-700/80 bg-[#0F172A]/80 p-4">
                  <div>
                    <p className="text-xs font-medium text-slate-400">Now Serving</p>
                    <div className="mt-1 flex items-center gap-2">
                      <span className="font-mono text-4xl font-bold tabular-nums text-teal-400 sm:text-5xl">
                        {entry.currentTokenNumber ? `#${entry.currentTokenNumber}` : '—'}
                      </span>
                      {entry.currentIsEmergency && (
                        <Siren className="h-5 w-5 text-red-400 shrink-0" aria-label="Emergency priority" />
                      )}
                    </div>
                  </div>

                  <div className="border-l border-slate-800 pl-4">
                    <p className="text-xs font-medium text-slate-400">Next Token</p>
                    <p className="font-mono mt-1 text-3xl font-bold tabular-nums text-white sm:text-4xl">
                      {entry.nextTokenNumber ? `#${entry.nextTokenNumber}` : '—'}
                    </p>
                  </div>

                  <div className="border-l border-slate-800 pl-4">
                    <p className="text-xs font-medium text-slate-400">Waiting</p>
                    <p className="font-mono mt-1 text-3xl font-bold tabular-nums text-slate-200 sm:text-4xl">
                      {entry.waitingCount}
                    </p>
                    <p className="mt-0.5 font-mono text-xs tabular-nums text-slate-400">
                      ~{entry.ewmaPaceMin.toFixed(0)}m/visit
                    </p>
                  </div>
                </div>

                {entry.activeNotice && (
                  <div className="mt-4 flex items-center gap-2 rounded-lg border border-amber-800/70 bg-amber-950/60 px-3.5 py-2 text-xs font-medium text-amber-200">
                    <AlertTriangle className="h-4 w-4 shrink-0 text-amber-400" aria-hidden="true" />
                    <span>{entry.activeNotice}</span>
                  </div>
                )}
              </article>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
