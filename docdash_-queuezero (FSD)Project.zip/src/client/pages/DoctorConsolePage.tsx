import {useCallback, useEffect, useState} from 'react';
import {Link} from 'react-router-dom';
import {MonitorPlay, RefreshCw} from 'lucide-react';
import type {DirectoryDoctor, DoctorConsoleData} from '../../shared/types';
import {fetchDirectory, fetchDoctorConsole} from '../api';
import {useQueueSocket} from '../useQueueSocket';
import {DoctorConsolePanel} from '../components/DoctorConsolePanel';

export function DoctorConsolePage() {
  const [doctors, setDoctors] = useState<DirectoryDoctor[]>([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState('doc-mehta');
  const [selectedShiftId, setSelectedShiftId] = useState<string | undefined>(undefined);
  const [consoleData, setConsoleData] = useState<DoctorConsoleData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadConsole = useCallback(async (docId: string, shiftId?: string) => {
    try {
      const data = await fetchDoctorConsole(docId, shiftId);
      setConsoleData(data);
      setError(null);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchDirectory()
      .then((res) => setDoctors(res.doctors))
      .catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    void loadConsole(selectedDoctorId, selectedShiftId);
  }, [selectedDoctorId, selectedShiftId, loadConsole]);

  const {syncStatus, secondsAgo, markSynced} = useQueueSocket((event) => {
    if (!event.doctorId || event.doctorId === selectedDoctorId || event.type === 'queue:reset') {
      void loadConsole(selectedDoctorId, selectedShiftId).then(markSynced);
    }
  });

  return (
    <main className="mx-auto max-w-[1200px] space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      {/* Top Staff Selector Toolbar */}
      <div className="flex flex-col gap-4 rounded-xl border border-slate-200 bg-white p-5 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-xs font-semibold text-teal-700">Clinic Operations &amp; Staff Console</p>
          <h1 className="font-display mt-0.5 text-2xl font-bold text-slate-900">
            Doctor Queue Management
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <label htmlFor="console-doctor-select" className="text-xs font-medium text-slate-600">
              Clinician:
            </label>
            <select
              id="console-doctor-select"
              value={selectedDoctorId}
              onChange={(e) => {
                setSelectedDoctorId(e.target.value);
                setSelectedShiftId(undefined);
              }}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-900"
            >
              {doctors.map((doc) => (
                <option key={doc.id} value={doc.id}>
                  {doc.name} · {doc.specialty}
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={() => void loadConsole(selectedDoctorId, selectedShiftId).then(markSynced)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
            <span className="font-mono tabular-nums">
              {syncStatus === 'live' ? 'Live' : 'Sync'} · {secondsAgo}s
            </span>
          </button>

          <Link
            to="/board"
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 whitespace-nowrap shrink-0"
          >
            <MonitorPlay className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Open Lobby Board</span>
          </Link>
        </div>
      </div>

      {loading && !consoleData ? (
        <div className="h-96 animate-pulse rounded-xl border border-slate-200 bg-white" />
      ) : error || !consoleData ? (
        <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-sm text-red-900">
          {error || 'Unable to load doctor console.'}
        </div>
      ) : (
        <DoctorConsolePanel
          data={consoleData}
          onChangeShift={(shiftId) => setSelectedShiftId(shiftId)}
          onUpdated={setConsoleData}
        />
      )}
    </main>
  );
}
