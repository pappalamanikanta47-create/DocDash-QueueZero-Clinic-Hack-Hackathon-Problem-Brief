import {useCallback, useEffect, useState} from 'react';
import {CheckCircle2, RotateCcw, Ticket, ArrowRight} from 'lucide-react';
import type {DoctorConsoleData, PublicBoardEntry, TokenTrackerView} from '../../shared/types';
import {
  bookToken,
  fetchDoctorConsole,
  fetchPublicBoard,
  fetchTokenTracker,
  lookupToken,
  resetDemoState,
} from '../api';
import {useQueueSocket} from '../useQueueSocket';
import {PatientTrackerCard} from '../components/PatientTrackerCard';
import {DoctorConsolePanel} from '../components/DoctorConsolePanel';
import {StatusLabel} from '../components/StatusLabel';

const DEMO_DOC_ID = 'doc-mehta';
const DEMO_SHIFT_ID = 'shift-mehta-morning';

export function DemoSplitPage() {
  const [consoleData, setConsoleData] = useState<DoctorConsoleData | null>(null);
  const [patientTracker, setPatientTracker] = useState<TokenTrackerView | null>(null);
  const [boardEntry, setBoardEntry] = useState<PublicBoardEntry | null>(null);

  const [patientName, setPatientName] = useState('Patient A');
  const [contactNumber, setContactNumber] = useState('+91 98450 11223');
  const [bookingBusy, setBookingBusy] = useState(false);
  const [resetBusy, setResetBusy] = useState(false);
  const [demoNotice, setDemoNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadAll = useCallback(async (trackedTokenId?: string) => {
    try {
      const [docConsole, board] = await Promise.all([
        fetchDoctorConsole(DEMO_DOC_ID, DEMO_SHIFT_ID),
        fetchPublicBoard('clinic-central'),
      ]);
      setConsoleData(docConsole);
      setBoardEntry(board.entries.find((e) => e.doctorId === DEMO_DOC_ID) ?? null);

      if (trackedTokenId) {
        const tr = await fetchTokenTracker(trackedTokenId);
        setPatientTracker(tr);
      } else {
        // Check if Token #14 already exists from an earlier booking in this session
        try {
          const existing14 = await lookupToken(DEMO_SHIFT_ID, 14);
          setPatientTracker(existing14);
        } catch {
          setPatientTracker(null);
        }
      }
      setError(null);
    } catch (err) {
      setError((err as Error).message);
    }
  }, []);

  useEffect(() => {
    void loadAll();
  }, [loadAll]);

  const {syncStatus, secondsAgo, markSynced} = useQueueSocket((event) => {
    if (event.type === 'queue:reset') {
      setPatientTracker(null);
      void loadAll().then(markSynced);
      return;
    }
    if (!event.doctorId || event.doctorId === DEMO_DOC_ID) {
      void loadAll(patientTracker?.token.id).then(markSynced);
    }
  });

  const handleBookDemoToken = async (e: React.FormEvent) => {
    e.preventDefault();
    setBookingBusy(true);
    setError(null);
    try {
      const tracker = await bookToken({
        shiftId: DEMO_SHIFT_ID,
        patientName,
        contactNumber,
      });
      setPatientTracker(tracker);
      try {
        localStorage.setItem('queuezero_last_token_id', tracker.token.id);
      } catch {
        // Ignore
      }
      setDemoNotice(
        `Issued Token #${tracker.token.tokenNumber} for ${tracker.token.patientName}. Now click "Call Next Patient" on Dr. Mehta's console.`
      );
      await loadAll(tracker.token.id);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBookingBusy(false);
    }
  };

  const handleResetDemo = async () => {
    setResetBusy(true);
    setError(null);
    try {
      const res = await resetDemoState();
      setPatientTracker(null);
      setPatientName('Patient A');
      setContactNumber('+91 98450 11223');
      setDemoNotice(res.message);
      await loadAll();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setResetBusy(false);
    }
  };

  const step1Done = Boolean(patientTracker);
  const step2Done = Boolean(patientTracker && patientTracker.patientsAhead <= 2);

  return (
    <main className="mx-auto max-w-[1400px] space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      {/* Top Demo Banner & Reset Control */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 sm:p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-xs font-semibold text-teal-700">
              End-to-End Split-Screen Walkthrough · Dr. Arjun Mehta (Cardiology)
            </p>
            <h1 className="font-display mt-1 text-2xl font-bold text-slate-900">
              Live Queue Synchronization Demo
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              Both panes connect to the live Express + SQLite + WebSocket server. Actions in Dr. Mehta&apos;s console update Patient A and the lobby board immediately.
            </p>
          </div>

          <button
            type="button"
            disabled={resetBusy}
            onClick={handleResetDemo}
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-800 hover:bg-slate-50 disabled:opacity-60 whitespace-nowrap shrink-0"
          >
            <RotateCcw className="h-4 w-4 text-teal-700" aria-hidden="true" />
            <span>{resetBusy ? 'Resetting...' : 'Reset Demo State'}</span>
          </button>
        </div>

        {/* 3-Step Checklist */}
        <div className="mt-5 grid grid-cols-1 gap-3 border-t border-slate-100 pt-4 md:grid-cols-3">
          <div
            className={`flex items-start gap-2.5 rounded-lg border p-3 ${
              step1Done
                ? 'border-emerald-200 bg-emerald-50/70 text-emerald-950'
                : 'border-teal-200 bg-teal-50/50 text-slate-900'
            }`}
          >
            <CheckCircle2
              className={`mt-0.5 h-4 w-4 shrink-0 ${step1Done ? 'text-emerald-700' : 'text-slate-400'}`}
              aria-hidden="true"
            />
            <div className="text-xs">
              <p className="font-bold">1. Book Token #14 as Patient A</p>
              <p className="mt-0.5 text-slate-600">
                Initially sees Token #11 in consultation and ~36 min estimated wait.
              </p>
            </div>
          </div>

          <div
            className={`flex items-start gap-2.5 rounded-lg border p-3 ${
              step2Done
                ? 'border-emerald-200 bg-emerald-50/70 text-emerald-950'
                : 'border-slate-200 bg-slate-50 text-slate-800'
            }`}
          >
            <CheckCircle2
              className={`mt-0.5 h-4 w-4 shrink-0 ${step2Done ? 'text-emerald-700' : 'text-slate-400'}`}
              aria-hidden="true"
            />
            <div className="text-xs">
              <p className="font-bold">2. Click Call Next Patient</p>
              <p className="mt-0.5 text-slate-600">
                Dr. Mehta completes #11 and calls #12 in the right-hand console.
              </p>
            </div>
          </div>

          <div
            className={`flex items-start gap-2.5 rounded-lg border p-3 ${
              step2Done
                ? 'border-amber-300 bg-amber-50 text-amber-950'
                : 'border-slate-200 bg-slate-50 text-slate-800'
            }`}
          >
            <CheckCircle2
              className={`mt-0.5 h-4 w-4 shrink-0 ${step2Done ? 'text-amber-700' : 'text-slate-400'}`}
              aria-hidden="true"
            />
            <div className="text-xs">
              <p className="font-bold">3. Instant Arrival Alert</p>
              <p className="mt-0.5 text-slate-600">
                Patient view updates to 2 ahead, ~24 min wait, and amber arrival banner.
              </p>
            </div>
          </div>
        </div>

        {demoNotice && (
          <p className="mt-3 text-xs font-medium text-teal-800">{demoNotice}</p>
        )}
        {error && (
          <p className="mt-3 text-xs font-medium text-red-700">{error}</p>
        )}
      </section>

      {/* Split Screen: Left Patient A, Right Dr. Mehta Console */}
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
        {/* Left Pane: Patient View */}
        <div className="space-y-4 xl:col-span-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold text-slate-900">
              Patient View (Mobile / Browser)
            </h2>
            <span className="font-mono text-xs tabular-nums text-slate-500">
              {patientTracker ? `Token #${patientTracker.token.tokenNumber}` : 'Ready to book'}
            </span>
          </div>

          {patientTracker ? (
            <PatientTrackerCard
              tracker={patientTracker}
              syncStatus={syncStatus}
              secondsAgo={secondsAgo}
              onRefresh={() => void loadAll(patientTracker.token.id).then(markSynced)}
              onUpdated={setPatientTracker}
              compact
            />
          ) : (
            <section className="rounded-xl border border-slate-200 bg-white p-6">
              <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <p className="text-xs font-semibold text-teal-700">
                    Cardiology · Cityside Heart &amp; Medical Center
                  </p>
                  <h3 className="font-display mt-1 text-xl font-bold text-slate-900">
                    Book Consultation Token with Dr. Arjun Mehta
                  </h3>
                  <p className="mt-1 text-sm text-slate-600">
                    Morning Shift (09:00–13:00) · Currently serving{' '}
                    <strong className="font-mono tabular-nums text-slate-900">
                      #{consoleData?.currentToken?.tokenNumber ?? 11}
                    </strong>
                    {' · '}
                    <strong className="font-mono tabular-nums text-slate-900">
                      {((consoleData?.currentToken ? 1 : 0) + (consoleData?.waitingQueue.length ?? 2)) *
                        (consoleData?.doctor.ewmaPaceMin ?? 12)}{' '}
                      min
                    </strong>{' '}
                    est. wait
                  </p>
                </div>
                <Ticket className="h-6 w-6 shrink-0 text-teal-700" aria-hidden="true" />
              </div>

              <form onSubmit={handleBookDemoToken} className="mt-5 space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label htmlFor="demo-patient-name" className="block text-xs font-semibold text-slate-700">
                      Patient Name
                    </label>
                    <input
                      id="demo-patient-name"
                      type="text"
                      required
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                    />
                  </div>
                  <div>
                    <label htmlFor="demo-contact" className="block text-xs font-semibold text-slate-700">
                      Contact Number
                    </label>
                    <input
                      id="demo-contact"
                      type="tel"
                      required
                      value={contactNumber}
                      onChange={(e) => setContactNumber(e.target.value)}
                      className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <span className="font-mono text-xs tabular-nums text-slate-500">
                    Next sequential token: #{(consoleData?.activeShift.lastTokenNumber ?? 13) + 1}
                  </span>
                  <button
                    type="submit"
                    disabled={bookingBusy}
                    className="inline-flex items-center gap-2 rounded-lg bg-teal-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-teal-700 disabled:opacity-60"
                  >
                    <span>
                      {bookingBusy
                        ? 'Booking...'
                        : `Book Token #${(consoleData?.activeShift.lastTokenNumber ?? 13) + 1} as ${patientName || 'Patient A'}`}
                    </span>
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              </form>
            </section>
          )}
        </div>

        {/* Right Pane: Doctor Console */}
        <div className="space-y-4 xl:col-span-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold text-slate-900">
              Doctor &amp; Staff Console (Dr. Mehta)
            </h2>
            <span className="font-mono text-xs tabular-nums text-slate-500">
              WebSocket · {syncStatus === 'live' ? 'Connected' : 'Syncing'}
            </span>
          </div>

          {consoleData ? (
            <DoctorConsolePanel
              data={consoleData}
              onChangeShift={() => {}}
              onUpdated={(next) => {
                setConsoleData(next);
                void loadAll(patientTracker?.token.id);
              }}
              compact
            />
          ) : (
            <div className="h-80 animate-pulse rounded-xl border border-slate-200 bg-white" />
          )}
        </div>
      </div>

      {/* Bottom Strip: Public Waiting-Room Board Preview (Dark Mode) */}
      {boardEntry && (
        <section className="rounded-xl border border-slate-800 bg-[#0F172A] p-5 text-slate-100">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs font-medium text-teal-400">
                Public Waiting-Room Display Preview (Privacy-Safe · No Patient Names)
              </p>
              <h3 className="font-display mt-1 text-lg font-bold text-white">
                {boardEntry.doctorName} · {boardEntry.roomNumber} · {boardEntry.clinicName}
              </h3>
            </div>
            <StatusLabel
              status={boardEntry.availability}
              dark
              delayMinutes={boardEntry.delayMinutes}
            />
          </div>

          <div className="mt-4 grid grid-cols-3 gap-4 rounded-lg border border-slate-800 bg-[#1E293B] p-4">
            <div>
              <p className="text-xs text-slate-400">Now Serving</p>
              <p className="font-mono mt-0.5 text-3xl font-bold tabular-nums text-teal-400">
                {boardEntry.currentTokenNumber ? `#${boardEntry.currentTokenNumber}` : '—'}
              </p>
            </div>
            <div className="border-l border-slate-700 pl-4">
              <p className="text-xs text-slate-400">Next Token</p>
              <p className="font-mono mt-0.5 text-3xl font-bold tabular-nums text-white">
                {boardEntry.nextTokenNumber ? `#${boardEntry.nextTokenNumber}` : '—'}
              </p>
            </div>
            <div className="border-l border-slate-700 pl-4">
              <p className="text-xs text-slate-400">Waiting Count</p>
              <p className="font-mono mt-0.5 text-3xl font-bold tabular-nums text-slate-200">
                {boardEntry.waitingCount}
              </p>
            </div>
          </div>
        </section>
      )}
    </main>
  );
}
