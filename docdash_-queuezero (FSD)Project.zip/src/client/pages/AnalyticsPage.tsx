import {useCallback, useEffect, useMemo, useState} from 'react';
import {BarChart3, Calculator, Database, ShieldAlert} from 'lucide-react';
import type {AuditEntry, Clinic, HeatmapCell} from '../../shared/types';
import {fetchAnalytics, fetchDirectory} from '../api';
import {useQueueSocket} from '../useQueueSocket';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const HOURS = ['09:00', '10:00', '11:00', '12:00', '16:00', '17:00', '18:00', '19:00'];

function heatCellStyle(avgWait: number): string {
  if (avgWait < 16) return 'bg-teal-50 text-teal-900 border-teal-200';
  if (avgWait < 25) return 'bg-teal-100 text-teal-950 border-teal-300';
  if (avgWait < 34) return 'bg-amber-100 text-amber-950 border-amber-300';
  return 'bg-rose-100 text-rose-950 border-rose-300';
}

export function AnalyticsPage() {
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [selectedClinicId, setSelectedClinicId] = useState('all');
  const [cells, setCells] = useState<HeatmapCell[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditEntry[]>([]);
  const [hoveredCell, setHoveredCell] = useState<HeatmapCell | null>(null);
  const [loading, setLoading] = useState(true);

  const loadAnalytics = useCallback(async () => {
    try {
      const data = await fetchAnalytics(selectedClinicId);
      setCells(data.cells);
      setAuditLogs(data.auditLogs);
    } finally {
      setLoading(false);
    }
  }, [selectedClinicId]);

  useEffect(() => {
    void fetchDirectory()
      .then((d) => setClinics(d.clinics))
      .catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    void loadAnalytics();
  }, [loadAnalytics]);

  useQueueSocket(() => {
    void loadAnalytics();
  });

  const cellLookup = useMemo(() => {
    const map = new Map<string, HeatmapCell>();
    for (const c of cells) {
      map.set(`${c.dayOfWeek}-${c.hourLabel}`, c);
    }
    return map;
  }, [cells]);

  return (
    <main className="mx-auto max-w-[1280px] space-y-8 px-4 py-8 sm:px-6 lg:px-8">
      <div>
        <p className="text-xs font-semibold text-teal-700">
          Operational Insights &amp; Queue Engineering
        </p>
        <h1 className="font-display mt-1 text-2xl font-bold text-slate-900 sm:text-3xl">
          Wait-Time Heatmap, EWMA Model &amp; Audit Log
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-slate-600">
          Explore historical clinic congestion patterns to pick calmer hours, review how dynamic wait times are calculated, and inspect staff queue audit records.
        </p>
      </div>

      {/* Stretch Feature: Clinic Wait-Time Heatmap */}
      <section className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex flex-col gap-4 border-b border-slate-100 pb-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-2.5">
            <BarChart3 className="h-5 w-5 text-teal-700" aria-hidden="true" />
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900">
                Historical Average Wait-Time Heatmap (Minutes)
              </h2>
              <p className="text-xs text-slate-500">
                Hover or tap any slot to inspect average wait duration and patient volume.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => setSelectedClinicId('all')}
              className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 ${
                selectedClinicId === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All 4 Clinics
            </button>
            {clinics.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setSelectedClinicId(c.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 ${
                  selectedClinicId === c.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {c.neighborhood}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="mt-5 h-64 animate-pulse rounded-lg bg-slate-100" />
        ) : (
          <div className="mt-5 overflow-x-auto">
            <table className="w-full min-w-[640px] border-separate border-spacing-1.5 text-center text-xs">
              <thead>
                <tr className="text-slate-500">
                  <th className="py-1 text-left font-medium">Day / Shift Hour</th>
                  {HOURS.map((hr) => (
                    <th key={hr} className="py-1 font-mono font-semibold tabular-nums">
                      {hr}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {DAYS.map((day) => (
                  <tr key={day}>
                    <td className="pr-3 text-left font-semibold text-slate-800">{day}</td>
                    {HOURS.map((hr) => {
                      const cell = cellLookup.get(`${day}-${hr}`);
                      if (!cell) return <td key={hr}>—</td>;
                      return (
                        <td key={hr}>
                          <button
                            type="button"
                            onMouseEnter={() => setHoveredCell(cell)}
                            onFocus={() => setHoveredCell(cell)}
                            onClick={() => setHoveredCell(cell)}
                            className={`w-full rounded-md border px-2 py-2.5 font-mono text-xs font-semibold tabular-nums transition-transform hover:scale-[1.03] ${heatCellStyle(
                              cell.avgWaitMin
                            )}`}
                          >
                            {cell.avgWaitMin}m
                          </button>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="mt-4 flex flex-wrap items-center justify-between gap-4 border-t border-slate-100 pt-4 text-xs text-slate-600">
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-medium text-slate-700">Wait Band:</span>
            <span className="rounded border border-teal-200 bg-teal-50 px-2 py-0.5 text-teal-900">
              &lt;16m Calm
            </span>
            <span className="rounded border border-teal-300 bg-teal-100 px-2 py-0.5 text-teal-950">
              16–24m Moderate
            </span>
            <span className="rounded border border-amber-300 bg-amber-100 px-2 py-0.5 text-amber-950">
              25–33m Busy
            </span>
            <span className="rounded border border-rose-300 bg-rose-100 px-2 py-0.5 text-rose-950">
              34m+ Peak Rush
            </span>
          </div>

          <div className="font-mono tabular-nums text-slate-800">
            {hoveredCell
              ? `${hoveredCell.dayOfWeek} ${hoveredCell.hourLabel}: ${hoveredCell.avgWaitMin} min avg wait · ${hoveredCell.patientVolume} patients/slot`
              : 'Select a slot to inspect volume'}
          </div>
        </div>
      </section>

      {/* Architecture & Wait-Time Algorithm Explanation */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
          <div className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-teal-700" aria-hidden="true" />
            <h2 className="font-display text-lg font-bold text-slate-900">
              Dynamic EWMA Wait-Time Formula
            </h2>
          </div>
          <p className="text-sm leading-relaxed text-slate-600">
            Rather than relying on static 15-minute slots, QueueZero tracks each doctor&apos;s rolling consultation pace with an Exponentially Weighted Moving Average (EWMA,{' '}
            <code className="font-mono text-xs text-slate-900">α = 0.35</code>):
          </p>
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3.5 font-mono text-xs text-slate-800 space-y-1.5">
            <p>pace_new = 0.35 × duration_last + 0.65 × pace_prev</p>
            <p>est_wait = max(0, round(patients_ahead × pace + delay_min))</p>
          </div>
          <ul className="space-y-1.5 text-xs text-slate-600 list-disc pl-4">
            <li>
              <strong>Patients Ahead</strong> counts the active consultation plus all higher-priority waiting or emergency tokens before yours.
            </li>
            <li>
              <strong>Instant Recalculation</strong> runs after every Call Next, Mark Completed, +10m Delay, Absent Skip, Restore, or Emergency Escalation.
            </li>
            <li>
              <strong>Arrival Alert</strong> triggers automatically in amber when 2 or fewer tokens remain ahead of you.
            </li>
          </ul>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
          <div className="flex items-center gap-2">
            <Database className="h-5 w-5 text-teal-700" aria-hidden="true" />
            <h2 className="font-display text-lg font-bold text-slate-900">
              Relational Data Model &amp; Atomic Locking
            </h2>
          </div>
          <p className="text-sm leading-relaxed text-slate-600">
            All state persists in SQLite (<code className="font-mono text-xs text-slate-900">queuezero.db</code>) with <code className="font-mono text-xs text-slate-900">BEGIN IMMEDIATE</code> transactions so concurrent staff actions never double-call a token.
          </p>
          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
              <p className="font-semibold text-slate-900">Clinics &amp; Doctors</p>
              <p className="mt-1 text-slate-600">
                4 branches with coordinates, 8 doctors with EWMA pace &amp; delay offsets.
              </p>
            </div>
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
              <p className="font-semibold text-slate-900">Shifts &amp; Tokens</p>
              <p className="mt-1 text-slate-600">
                Morning/Evening counters issuing sequential shift tokens + priority order.
              </p>
            </div>
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
              <p className="font-semibold text-slate-900">Check-In &amp; Notes</p>
              <p className="mt-1 text-slate-600">
                Optional Haversine ≤500m check-in distance &amp; post-visit prescriptions.
              </p>
            </div>
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
              <p className="font-semibold text-slate-900">Wait History &amp; Audits</p>
              <p className="mt-1 text-slate-600">
                Day/hour congestion series &amp; immutable log of escalations and delays.
              </p>
            </div>
          </div>
        </section>
      </div>

      {/* Audit Log Table */}
      <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="flex items-center gap-2 border-b border-slate-100 px-6 py-4">
          <ShieldAlert className="h-4 w-4 text-teal-700" aria-hidden="true" />
          <h2 className="font-display text-base font-bold text-slate-900">
            Clinic Queue &amp; Emergency Audit Log ({auditLogs.length})
          </h2>
        </div>

        {auditLogs.length === 0 ? (
          <p className="px-6 py-8 text-center text-sm text-slate-500">No audit entries recorded yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50 text-xs font-medium text-slate-500">
                  <th className="px-5 py-2.5">Event</th>
                  <th className="px-5 py-2.5">Clinician</th>
                  <th className="px-5 py-2.5">Actor</th>
                  <th className="px-5 py-2.5">Reason / Note</th>
                  <th className="px-5 py-2.5 text-right">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/70">
                    <td className="px-5 py-3 font-mono text-xs font-semibold text-slate-800 whitespace-nowrap">
                      {log.actionType.replace('_', ' ')}
                      {log.tokenNumber ? ` (#${log.tokenNumber})` : ''}
                    </td>
                    <td className="px-5 py-3 text-slate-800 whitespace-nowrap">{log.doctorName}</td>
                    <td className="px-5 py-3 text-slate-600 whitespace-nowrap">{log.actor}</td>
                    <td className="px-5 py-3 text-slate-700">{log.reason}</td>
                    <td className="px-5 py-3 text-right font-mono tabular-nums text-slate-500 whitespace-nowrap">
                      {new Date(log.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
}
