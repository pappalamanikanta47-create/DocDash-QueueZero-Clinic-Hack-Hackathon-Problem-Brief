export type Specialty =
  | 'General Medicine'
  | 'Pediatrics'
  | 'Orthopedics'
  | 'Cardiology';

export type DoctorAvailability =
  | 'available'
  | 'in_consultation'
  | 'delayed'
  | 'on_break';

export type TokenStatus =
  | 'waiting'
  | 'in_consultation'
  | 'delayed'
  | 'completed'
  | 'absent'
  | 'emergency';

export type ShiftPeriod = 'morning' | 'evening';

export interface Clinic {
  id: string;
  name: string;
  neighborhood: string;
  address: string;
  city: string;
  lat: number;
  lng: number;
  phone: string;
  imagePath: string;
}

export interface Doctor {
  id: string;
  clinicId: string;
  name: string;
  initials: string;
  specialty: Specialty;
  consultationFee: number;
  defaultDurationMin: number;
  ewmaPaceMin: number;
  delayMinutes: number;
  availability: DoctorAvailability;
  roomNumber: string;
  bio: string;
}

export interface Shift {
  id: string;
  doctorId: string;
  period: ShiftPeriod;
  label: string;
  isActive: boolean;
  lastTokenNumber: number;
}

export interface QueueToken {
  id: string;
  shiftId: string;
  doctorId: string;
  clinicId: string;
  tokenNumber: number;
  patientName: string;
  contactNumber: string;
  status: TokenStatus;
  priorityOrder: number;
  isEmergency: boolean;
  bookedAt: string;
  calledAt: string | null;
  completedAt: string | null;
  durationMinutes: number | null;
  checkedInAt: string | null;
  checkInDistanceM: number | null;
  visitNotes: string | null;
  prescriptionSummary: string | null;
}

export interface DirectoryDoctor extends Doctor {
  clinic: Clinic;
  shifts: Array<
    Shift & {
      waitingCount: number;
      currentTokenNumber: number | null;
      estimatedNextWaitMin: number;
    }
  >;
}

export interface TrackerQueueItem {
  tokenNumber: number;
  status: TokenStatus;
  isEmergency: boolean;
  isCurrentUser: boolean;
}

export interface TokenTrackerView {
  token: QueueToken;
  clinic: Clinic;
  doctor: Doctor;
  shift: Shift;
  currentTokenNumber: number | null;
  patientsAhead: number;
  estimatedWaitMinutes: number;
  arrivalAlert: boolean;
  queueSnapshot: TrackerQueueItem[];
  lastUpdatedAt: string;
}

export interface DoctorConsoleData {
  doctor: Doctor;
  clinic: Clinic;
  shifts: Shift[];
  activeShift: Shift;
  currentToken: QueueToken | null;
  waitingQueue: Array<QueueToken & { estimatedWaitMinutes: number }>;
  absentTokens: QueueToken[];
  completedTokens: QueueToken[];
  auditLogs: AuditEntry[];
  lastUpdatedAt: string;
}

export interface PublicBoardEntry {
  doctorId: string;
  doctorName: string;
  specialty: Specialty;
  roomNumber: string;
  clinicId: string;
  clinicName: string;
  shiftId: string;
  shiftLabel: string;
  availability: DoctorAvailability;
  delayMinutes: number;
  ewmaPaceMin: number;
  currentTokenNumber: number | null;
  currentIsEmergency: boolean;
  nextTokenNumber: number | null;
  waitingCount: number;
  activeNotice: string | null;
}

export interface HeatmapCell {
  clinicId: string;
  dayOfWeek: string;
  hourLabel: string;
  avgWaitMin: number;
  patientVolume: number;
}

export interface AuditEntry {
  id: string;
  doctorId: string;
  doctorName: string;
  shiftId: string;
  tokenId: string | null;
  tokenNumber: number | null;
  actionType:
    | 'emergency_escalation'
    | 'delay_added'
    | 'patient_absent'
    | 'token_restored'
    | 'demo_reset';
  actor: string;
  reason: string;
  createdAt: string;
}

export interface WsEvent {
  type: 'queue:updated' | 'queue:reset' | 'connected';
  doctorId?: string;
  shiftId?: string;
  timestamp: string;
}
