import Database from 'better-sqlite3';
import path from 'path';

const DB_PATH = path.resolve(process.cwd(), 'queuezero.db');

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initSchema(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS clinics (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      neighborhood TEXT NOT NULL,
      address TEXT NOT NULL,
      city TEXT NOT NULL,
      lat REAL NOT NULL,
      lng REAL NOT NULL,
      phone TEXT NOT NULL,
      image_path TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS doctors (
      id TEXT PRIMARY KEY,
      clinic_id TEXT NOT NULL REFERENCES clinics(id),
      name TEXT NOT NULL,
      initials TEXT NOT NULL,
      specialty TEXT NOT NULL,
      consultation_fee INTEGER NOT NULL,
      default_duration_min INTEGER NOT NULL,
      ewma_pace_min REAL NOT NULL,
      delay_minutes INTEGER NOT NULL DEFAULT 0,
      availability TEXT NOT NULL,
      room_number TEXT NOT NULL,
      bio TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS shifts (
      id TEXT PRIMARY KEY,
      doctor_id TEXT NOT NULL REFERENCES doctors(id),
      period TEXT NOT NULL,
      label TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      last_token_number INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS queue_tokens (
      id TEXT PRIMARY KEY,
      shift_id TEXT NOT NULL REFERENCES shifts(id),
      doctor_id TEXT NOT NULL REFERENCES doctors(id),
      clinic_id TEXT NOT NULL REFERENCES clinics(id),
      token_number INTEGER NOT NULL,
      patient_name TEXT NOT NULL,
      contact_number TEXT NOT NULL,
      status TEXT NOT NULL,
      priority_order INTEGER NOT NULL,
      is_emergency INTEGER NOT NULL DEFAULT 0,
      booked_at TEXT NOT NULL,
      called_at TEXT,
      completed_at TEXT,
      duration_minutes INTEGER,
      checked_in_at TEXT,
      check_in_distance_m INTEGER,
      visit_notes TEXT,
      prescription_summary TEXT,
      UNIQUE(shift_id, token_number)
    );

    CREATE TABLE IF NOT EXISTS wait_time_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      clinic_id TEXT NOT NULL REFERENCES clinics(id),
      day_of_week TEXT NOT NULL,
      hour_label TEXT NOT NULL,
      avg_wait_min INTEGER NOT NULL,
      patient_volume INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      doctor_id TEXT NOT NULL REFERENCES doctors(id),
      doctor_name TEXT NOT NULL,
      shift_id TEXT NOT NULL,
      token_id TEXT,
      token_number INTEGER,
      action_type TEXT NOT NULL,
      actor TEXT NOT NULL,
      reason TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);
}

export function resetAndSeedDatabase(): void {
  const tx = db.transaction(() => {
    db.exec(`
      DELETE FROM audit_logs;
      DELETE FROM wait_time_history;
      DELETE FROM queue_tokens;
      DELETE FROM shifts;
      DELETE FROM doctors;
      DELETE FROM clinics;
    `);

    const insertClinic = db.prepare(`
      INSERT INTO clinics (id, name, neighborhood, address, city, lat, lng, phone, image_path)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const clinics = [
      [
        'clinic-central',
        'Cityside Heart & Medical Center',
        'MG Road',
        '42 Residency Cross, MG Road',
        'Bengaluru',
        12.9756,
        77.6066,
        '+91 80 4120 8800',
        '/src/assets/images/clinic_central_heart_1794931721916.jpg',
      ],
      [
        'clinic-westside',
        'Westside Primary Care',
        'Indiranagar',
        '108 12th Main Road, Indiranagar',
        'Bengaluru',
        12.9784,
        77.6408,
        '+91 80 4155 2240',
        '/src/assets/images/clinic_westside_care_1794931721065.jpg',
      ],
      [
        'clinic-harbor',
        'Harmony Family & Pediatrics',
        'Koramangala',
        '19 4th Block, Koramangala',
        'Bengaluru',
        12.9352,
        77.6245,
        '+91 80 4190 6110',
        '/src/assets/images/clinic_harbor_pediatrics_1794931721651.jpg',
      ],
      [
        'clinic-northgate',
        'Northgate Ortho & Rehab',
        'Sadashivanagar',
        '7 Sankey Tank Road, Sadashivanagar',
        'Bengaluru',
        13.0068,
        77.5813,
        '+91 80 4177 9300',
        '/src/assets/images/clinic_northgate_ortho_1794931722161.jpg',
      ],
    ];
    for (const c of clinics) insertClinic.run(...c);

    const insertDoctor = db.prepare(`
      INSERT INTO doctors (
        id, clinic_id, name, initials, specialty, consultation_fee,
        default_duration_min, ewma_pace_min, delay_minutes, availability, room_number, bio
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const doctors = [
      [
        'doc-mehta',
        'clinic-central',
        'Dr. Arjun Mehta',
        'AM',
        'Cardiology',
        900,
        12,
        12.0,
        0,
        'in_consultation',
        'Suite C-201',
        'Senior Interventional Cardiologist · 16 yrs experience in preventive heart care & echocardiography.',
      ],
      [
        'doc-rao',
        'clinic-northgate',
        'Dr. Kavita Rao',
        'KR',
        'Cardiology',
        950,
        15,
        15.0,
        0,
        'available',
        'Suite N-104',
        'Non-invasive cardiologist specializing in hypertension management and cardiac rehabilitation.',
      ],
      [
        'doc-nair',
        'clinic-westside',
        'Dr. Priya Nair',
        'PN',
        'General Medicine',
        600,
        10,
        10.5,
        0,
        'in_consultation',
        'Room W-102',
        'Internal medicine specialist focused on acute primary care, metabolic health, and chronic follow-ups.',
      ],
      [
        'doc-joshi',
        'clinic-central',
        'Dr. Vikram Joshi',
        'VJ',
        'General Medicine',
        650,
        10,
        10.0,
        10,
        'delayed',
        'Room C-105',
        'Family physician managing respiratory infections, preventive screenings, and adult immunizations.',
      ],
      [
        'doc-kulkarni',
        'clinic-harbor',
        'Dr. Sneha Kulkarni',
        'SK',
        'Pediatrics',
        700,
        12,
        12.0,
        0,
        'in_consultation',
        'Room H-101',
        'Pediatrician dedicated to infant wellness, developmental milestones, and childhood allergy care.',
      ],
      [
        'doc-thomas',
        'clinic-westside',
        'Dr. Daniel Thomas',
        'DT',
        'Pediatrics',
        700,
        14,
        13.5,
        0,
        'available',
        'Room W-204',
        'Adolescent & pediatric acute care physician with warm child-friendly consultation pacing.',
      ],
      [
        'doc-deshmukh',
        'clinic-northgate',
        'Dr. Rohan Deshmukh',
        'RD',
        'Orthopedics',
        850,
        15,
        15.0,
        0,
        'in_consultation',
        'Suite N-202',
        'Sports injury and joint preservation specialist offering non-surgical and post-op care.',
      ],
      [
        'doc-iyer',
        'clinic-harbor',
        'Dr. Meera Iyer',
        'MI',
        'Orthopedics',
        800,
        14,
        14.0,
        0,
        'on_break',
        'Room H-203',
        'Spine and musculoskeletal clinician specializing in posture rehab and fracture follow-ups.',
      ],
    ];
    for (const d of doctors) insertDoctor.run(...d);

    const insertShift = db.prepare(`
      INSERT INTO shifts (id, doctor_id, period, label, is_active, last_token_number)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    const shifts: Array<[string, string, string, string, number, number]> = [
      ['shift-mehta-morning', 'doc-mehta', 'morning', 'Morning · 09:00–13:00', 1, 13],
      ['shift-mehta-evening', 'doc-mehta', 'evening', 'Evening · 16:00–20:00', 1, 2],
      ['shift-rao-morning', 'doc-rao', 'morning', 'Morning · 09:00–13:00', 1, 4],
      ['shift-rao-evening', 'doc-rao', 'evening', 'Evening · 16:00–20:00', 1, 0],
      ['shift-nair-morning', 'doc-nair', 'morning', 'Morning · 09:00–13:00', 1, 7],
      ['shift-nair-evening', 'doc-nair', 'evening', 'Evening · 16:00–20:00', 1, 1],
      ['shift-joshi-morning', 'doc-joshi', 'morning', 'Morning · 09:00–13:00', 1, 6],
      ['shift-joshi-evening', 'doc-joshi', 'evening', 'Evening · 16:00–20:00', 1, 0],
      ['shift-kulkarni-morning', 'doc-kulkarni', 'morning', 'Morning · 09:00–13:00', 1, 5],
      ['shift-kulkarni-evening', 'doc-kulkarni', 'evening', 'Evening · 16:00–20:00', 1, 0],
      ['shift-thomas-morning', 'doc-thomas', 'morning', 'Morning · 09:00–13:00', 1, 3],
      ['shift-thomas-evening', 'doc-thomas', 'evening', 'Evening · 16:00–20:00', 1, 1],
      ['shift-deshmukh-morning', 'doc-deshmukh', 'morning', 'Morning · 09:00–13:00', 1, 6],
      ['shift-deshmukh-evening', 'doc-deshmukh', 'evening', 'Evening · 16:00–20:00', 1, 0],
      ['shift-iyer-morning', 'doc-iyer', 'morning', 'Morning · 09:00–13:00', 1, 2],
      ['shift-iyer-evening', 'doc-iyer', 'evening', 'Evening · 16:00–20:00', 1, 3],
    ];
    for (const s of shifts) insertShift.run(...s);

    const insertToken = db.prepare(`
      INSERT INTO queue_tokens (
        id, shift_id, doctor_id, clinic_id, token_number, patient_name, contact_number,
        status, priority_order, is_emergency, booked_at, called_at, completed_at,
        duration_minutes, checked_in_at, check_in_distance_m, visit_notes, prescription_summary
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const now = Date.now();
    const iso = (offsetMin: number) => new Date(now + offsetMin * 60_000).toISOString();

    // Seed Dr. Mehta's Morning Shift: Tokens #1-#10 completed, #11 in_consultation, #12-#13 waiting
    // Next booked token is #14 -> Patient A sees #11 in consultation and 36 min estimated wait (3 * 12)
    const mehtaNames = [
      'Ramesh Kulkarni',
      'Anita Sharma',
      'Suresh Bhat',
      'Lakshmi Menon',
      'Deepak Verma',
      'Neha Kapoor',
      'Arvind Hegde',
      'Sunita Rao',
      'Karthik Pillai',
      'Bhavna Desai',
      'Mohan Krishnan',
      'Shruti Nair',
      'Tarun Malhotra',
    ];

    for (let i = 1; i <= 13; i++) {
      const idx = i - 1;
      const status = i <= 10 ? 'completed' : i === 11 ? 'in_consultation' : 'waiting';
      const bookedAt = iso(-150 + i * 6);
      const calledAt = i <= 11 ? iso(-120 + (i - 1) * 12) : null;
      const completedAt = i <= 10 ? iso(-108 + (i - 1) * 12) : null;
      const duration = i <= 10 ? 12 : null;
      const notes =
        i === 10
          ? 'Routine blood pressure review; resting ECG sinus rhythm at 72 bpm. Continue morning regimen and repeat lipid panel in 12 weeks.'
          : i === 9
            ? 'Mild exertional dyspnea evaluated; echocardiogram within normal limits. Advised brisk 30-min daily walking and hydration.'
            : null;
      const rx =
        i === 10
          ? 'Telmisartan 40 mg OD (morning) · Atorvastatin 10 mg HS · Low-sodium diet (<2g/day)'
          : i === 9
            ? 'Vitamin D3 60,000 IU weekly x 8 weeks · Follow-up BP log at next visit'
            : null;

      insertToken.run(
        `tok-mehta-m-${i}`,
        'shift-mehta-morning',
        'doc-mehta',
        'clinic-central',
        i,
        mehtaNames[idx],
        `+91 98450 ${String(10000 + i * 111).slice(0, 5)}`,
        status,
        i * 100,
        0,
        bookedAt,
        calledAt,
        completedAt,
        duration,
        i <= 12 ? bookedAt : null,
        i <= 12 ? 120 : null,
        notes,
        rx
      );
    }

    // Seed Dr. Mehta evening shift
    insertToken.run(
      'tok-mehta-e-1',
      'shift-mehta-evening',
      'doc-mehta',
      'clinic-central',
      1,
      'Gaurav Singh',
      '+91 98451 22001',
      'waiting',
      100,
      0,
      iso(-25),
      null,
      null,
      null,
      null,
      null,
      null,
      null
    );
    insertToken.run(
      'tok-mehta-e-2',
      'shift-mehta-evening',
      'doc-mehta',
      'clinic-central',
      2,
      'Nandini Bose',
      '+91 98451 22002',
      'waiting',
      200,
      0,
      iso(-18),
      null,
      null,
      null,
      null,
      null,
      null,
      null
    );

    // Seed Dr. Priya Nair (General Medicine - Westside) including an absent holding-bay token
    const nairTokens: Array<[number, string, string, string | null]> = [
      [1, 'Siddharth Roy', 'completed', 'Viral pharyngitis; throat clear. Rest and warm saline gargles advised.'],
      [2, 'Pooja Hegde', 'completed', 'Annual fasting glucose & thyroid panel reviewed; results within reference range.'],
      [3, 'Aakash Mehta', 'absent', null],
      [4, 'Divya Menon', 'in_consultation', null],
      [5, 'Rohan Chatterjee', 'waiting', null],
      [6, 'Meenakshi Iyer', 'waiting', null],
      [7, 'Varun Krishnan', 'waiting', null],
    ];
    for (const [num, name, status, note] of nairTokens) {
      insertToken.run(
        `tok-nair-m-${num}`,
        'shift-nair-morning',
        'doc-nair',
        'clinic-westside',
        num,
        name,
        `+91 98801 4400${num}`,
        status,
        num * 100,
        0,
        iso(-60 + num * 5),
        status === 'completed' || status === 'in_consultation' ? iso(-35 + num * 8) : null,
        status === 'completed' ? iso(-25 + num * 8) : null,
        status === 'completed' ? 10 : null,
        num >= 4 && status !== 'absent' ? iso(-20) : null,
        num >= 4 && status !== 'absent' ? 85 : null,
        note,
        note ? 'Paracetamol 500 mg SOS · Hydration 2.5L/day' : null
      );
    }

    // Seed Dr. Vikram Joshi (General Medicine - Delayed +10m)
    for (let i = 1; i <= 6; i++) {
      const status = i <= 3 ? 'completed' : i === 4 ? 'in_consultation' : 'waiting';
      insertToken.run(
        `tok-joshi-m-${i}`,
        'shift-joshi-morning',
        'doc-joshi',
        'clinic-central',
        i,
        ['Harish Gowda', 'Rekha Jain', 'Nikhil Shetty', 'Swati Bansal', 'Manoj Tiwari', 'Komal Gupta'][i - 1],
        `+91 98452 7700${i}`,
        status,
        i * 100,
        0,
        iso(-55 + i * 6),
        i <= 4 ? iso(-30 + i * 9) : null,
        i <= 3 ? iso(-20 + i * 9) : null,
        i <= 3 ? 10 : null,
        null,
        null,
        i <= 3 ? 'Upper respiratory symptoms resolving; vitals stable.' : null,
        i <= 3 ? 'Cetirizine 10 mg HS x 5 days · Steam inhalation twice daily' : null
      );
    }

    // Seed Dr. Sneha Kulkarni (Pediatrics - Harmony)
    for (let i = 1; i <= 5; i++) {
      const status = i <= 2 ? 'completed' : i === 3 ? 'in_consultation' : 'waiting';
      insertToken.run(
        `tok-kulkarni-m-${i}`,
        'shift-kulkarni-morning',
        'doc-kulkarni',
        'clinic-harbor',
        i,
        ['Aarav Patel', 'Diya Narayanan', 'Kabir Sengupta', 'Ananya Rao', 'Vihaan Reddy'][i - 1],
        `+91 99001 3300${i}`,
        status,
        i * 100,
        0,
        iso(-50 + i * 7),
        i <= 3 ? iso(-28 + i * 11) : null,
        i <= 2 ? iso(-16 + i * 11) : null,
        i <= 2 ? 12 : null,
        null,
        null,
        i <= 2 ? 'Routine pediatric growth & immunization check completed.' : null,
        i <= 2 ? 'Oral Vitamin D drops 400 IU daily · Next booster due in 6 months' : null
      );
    }

    // Seed Dr. Rohan Deshmukh (Orthopedics - Northgate)
    for (let i = 1; i <= 6; i++) {
      const status = i <= 2 ? 'completed' : i === 3 ? 'in_consultation' : 'waiting';
      insertToken.run(
        `tok-deshmukh-m-${i}`,
        'shift-deshmukh-morning',
        'doc-deshmukh',
        'clinic-northgate',
        i,
        ['Prakash Menon', 'Shalini Verma', 'Ajay Krishnan', 'Geeta Kulkarni', 'Rakesh Nair', 'Preeti Sinha'][i - 1],
        `+91 97400 5500${i}`,
        status,
        i * 100,
        0,
        iso(-65 + i * 8),
        i <= 3 ? iso(-35 + i * 14) : null,
        i <= 2 ? iso(-20 + i * 14) : null,
        i <= 2 ? 15 : null,
        null,
        null,
        i <= 2 ? 'Knee osteoarthritis mobility assessment; quadriceps strengthening advised.' : null,
        i <= 2 ? 'Physiotherapy 3x/week · Topical diclofenac gel BID' : null
      );
    }

    // Seed remaining doctors lightly so every doctor has realistic live queue state
    for (let i = 1; i <= 4; i++) {
      const status = i === 1 ? 'completed' : i === 2 ? 'waiting' : 'waiting';
      insertToken.run(
        `tok-rao-m-${i}`,
        'shift-rao-morning',
        'doc-rao',
        'clinic-northgate',
        i,
        ['Srinivas Murthy', 'Padma Iyengar', 'Chetan Kumar', 'Usha Raman'][i - 1],
        `+91 98440 6600${i}`,
        status,
        i * 100,
        0,
        iso(-30 + i * 5),
        i === 1 ? iso(-25) : null,
        i === 1 ? iso(-10) : null,
        i === 1 ? 15 : null,
        null,
        null,
        null,
        null
      );
    }

    for (let i = 1; i <= 3; i++) {
      insertToken.run(
        `tok-thomas-m-${i}`,
        'shift-thomas-morning',
        'doc-thomas',
        'clinic-westside',
        i,
        ['Maya Krishnan', 'Ishaan Das', 'Zoya Khan'][i - 1],
        `+91 98860 1100${i}`,
        'waiting',
        i * 100,
        0,
        iso(-20 + i * 4),
        null,
        null,
        null,
        null,
        null,
        null,
        null
      );
    }

    // Seed Dr. Meera Iyer evening tokens (currently on morning break)
    for (let i = 1; i <= 3; i++) {
      insertToken.run(
        `tok-iyer-e-${i}`,
        'shift-iyer-evening',
        'doc-iyer',
        'clinic-harbor',
        i,
        ['Ashok Hegde', 'Nirmala Devi', 'Sandeep Varma'][i - 1],
        `+91 98455 9900${i}`,
        'waiting',
        i * 100,
        0,
        iso(-15 + i * 3),
        null,
        null,
        null,
        null,
        null,
        null,
        null
      );
    }

    // Seed realistic historical wait-time heatmap data across all 4 clinics (Mon-Sat, 09:00-19:00)
    const insertHeat = db.prepare(`
      INSERT INTO wait_time_history (clinic_id, day_of_week, hour_label, avg_wait_min, patient_volume)
      VALUES (?, ?, ?, ?, ?)
    `);
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const hours = ['09:00', '10:00', '11:00', '12:00', '16:00', '17:00', '18:00', '19:00'];
    const clinicFactors: Record<string, number> = {
      'clinic-central': 1.15,
      'clinic-westside': 0.9,
      'clinic-harbor': 1.0,
      'clinic-northgate': 1.05,
    };

    for (const clinicId of Object.keys(clinicFactors)) {
      const factor = clinicFactors[clinicId];
      days.forEach((day, dIdx) => {
        hours.forEach((hour, hIdx) => {
          const isPeakHour = hour === '10:00' || hour === '11:00' || hour === '17:00' || hour === '18:00';
          const isWeekendPeak = day === 'Sat' && (hour === '10:00' || hour === '11:00');
          const isMonRush = day === 'Mon' && isPeakHour;
          const base = 11 + ((dIdx * 3 + hIdx * 5) % 9);
          const peakBoost = (isPeakHour ? 12 : 0) + (isWeekendPeak ? 10 : 0) + (isMonRush ? 7 : 0);
          const avgWait = Math.round((base + peakBoost) * factor);
          const volume = Math.round((8 + (isPeakHour ? 11 : 3) + (isWeekendPeak ? 6 : 0)) * factor);
          insertHeat.run(clinicId, day, hour, avgWait, volume);
        });
      });
    }

    // Initial audit entry for Dr. Joshi delay and Dr. Nair absent skip
    const insertAudit = db.prepare(`
      INSERT INTO audit_logs (id, doctor_id, doctor_name, shift_id, token_id, token_number, action_type, actor, reason, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertAudit.run(
      'audit-seed-1',
      'doc-joshi',
      'Dr. Vikram Joshi',
      'shift-joshi-morning',
      null,
      null,
      'delay_added',
      'Clinic Coordinator',
      'Morning outpatient rounds ran 10 minutes over schedule.',
      iso(-18)
    );
    insertAudit.run(
      'audit-seed-2',
      'doc-nair',
      'Dr. Priya Nair',
      'shift-nair-morning',
      'tok-nair-m-3',
      3,
      'patient_absent',
      'Dr. Priya Nair',
      'Token #3 did not respond after two calls; moved to holding bay.',
      iso(-11)
    );
  });

  tx();
}

export function ensureInitialized(): void {
  initSchema();
  const count = db.prepare('SELECT COUNT(*) as cnt FROM clinics').get() as { cnt: number };
  if (count.cnt === 0) {
    resetAndSeedDatabase();
  }
}
