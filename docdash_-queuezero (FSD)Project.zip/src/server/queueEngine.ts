import {db} from './db.ts';
import type {
  AuditEntry,
  Clinic,
  DirectoryDoctor,
  Doctor,
  DoctorAvailability,
  DoctorConsoleData,
  HeatmapCell,
  PublicBoardEntry,
  QueueToken,
  Shift,
  ShiftPeriod,
  Specialty,
  TokenStatus,
  TokenTrackerView,
} from '../shared/types.ts';

const EWMA_ALPHA = 0.35;

interface ClinicRow {
  id: string;
  name: string;
  neighborhood: string;
  address: string;
  city: string;
  lat: number;
  lng: number;
  phone: string;
  image_path: string;
}

interface DoctorRow {
  id: string;
  clinic_id: string;
  name: string;
  initials: string;
  specialty: string;
  consultation_fee: number;
  default_duration_min: number;
  ewma_pace_min: number;
  delay_minutes: number;
  availability: string;
  room_number: string;
  bio: string;
}

interface ShiftRow {
  id: string;
  doctor_id: string;
  period: string;
  label: string;
  is_active: number;
  last_token_number: number;
}

interface TokenRow {
  id: string;
  shift_id: string;
  doctor_id: string;
  clinic_id: string;
  token_number: number;
  patient_name: string;
  contact_number: string;
  status: string;
  priority_order: number;
  is_emergency: number;
  booked_at: string;
  called_at: string | null;
  completed_at: string | null;
  duration_minutes: number | null;
  checked_in_at: string | null;
  check_in_distance_m: number | null;
  visit_notes: string | null;
  prescription_summary: string | null;
}

interface AuditRow {
  id: string;
  doctor_id: string;
  doctor_name: string;
  shift_id: string;
  token_id: string | null;
  token_number: number | null;
  action_type: string;
  actor: string;
  reason: string;
  created_at: string;
}

function mapClinic(row: ClinicRow): Clinic {
  return {
    id: row.id,
    name: row.name,
    neighborhood: row.neighborhood,
    address: row.address,
    city: row.city,
    lat: row.lat,
    lng: row.lng,
    phone: row.phone,
    imagePath: row.image_path,
  };
}

function mapDoctor(row: DoctorRow): Doctor {
  return {
    id: row.id,
    clinicId: row.clinic_id,
    name: row.name,
    initials: row.initials,
    specialty: row.specialty as Specialty,
    consultationFee: row.consultation_fee,
    defaultDurationMin: row.default_duration_min,
    ewmaPaceMin: row.ewma_pace_min,
    delayMinutes: row.delay_minutes,
    availability: row.availability as DoctorAvailability,
    roomNumber: row.room_number,
    bio: row.bio,
  };
}

function mapShift(row: ShiftRow): Shift {
  return {
    id: row.id,
    doctorId: row.doctor_id,
    period: row.period as ShiftPeriod,
    label: row.label,
    isActive: row.is_active === 1,
    lastTokenNumber: row.last_token_number,
  };
}

function mapToken(row: TokenRow): QueueToken {
  return {
    id: row.id,
    shiftId: row.shift_id,
    doctorId: row.doctor_id,
    clinicId: row.clinic_id,
    tokenNumber: row.token_number,
    patientName: row.patient_name,
    contactNumber: row.contact_number,
    status: row.status as TokenStatus,
    priorityOrder: row.priority_order,
    isEmergency: row.is_emergency === 1,
    bookedAt: row.booked_at,
    calledAt: row.called_at,
    completedAt: row.completed_at,
    durationMinutes: row.duration_minutes,
    checkedInAt: row.checked_in_at,
    checkInDistanceM: row.check_in_distance_m,
    visitNotes: row.visit_notes,
    prescriptionSummary: row.prescription_summary,
  };
}

function mapAudit(row: AuditRow): AuditEntry {
  return {
    id: row.id,
    doctorId: row.doctor_id,
    doctorName: row.doctor_name,
    shiftId: row.shift_id,
    tokenId: row.token_id,
    tokenNumber: row.token_number,
    actionType: row.action_type as AuditEntry['actionType'],
    actor: row.actor,
    reason: row.reason,
    createdAt: row.created_at,
  };
}

function getOrderedActiveQueue(shiftId: string): TokenRow[] {
  return db
    .prepare(
      `SELECT * FROM queue_tokens
       WHERE shift_id = ? AND status IN ('in_consultation', 'waiting', 'emergency')
       ORDER BY CASE WHEN status = 'in_consultation' THEN 0 ELSE 1 END,
                priority_order ASC,
                token_number ASC`
    )
    .all(shiftId) as TokenRow[];
}

function getOrderedWaitingQueue(shiftId: string): TokenRow[] {
  return db
    .prepare(
      `SELECT * FROM queue_tokens
       WHERE shift_id = ? AND status IN ('waiting', 'emergency')
       ORDER BY priority_order ASC, token_number ASC`
    )
    .all(shiftId) as TokenRow[];
}

function computeWaitMinutes(aheadCount: number, doctor: DoctorRow): number {
  if (aheadCount <= 0) return 0;
  return Math.max(0, Math.round(aheadCount * doctor.ewma_pace_min + doctor.delay_minutes));
}

function insertAuditLog(params: {
  doctorId: string;
  doctorName: string;
  shiftId: string;
  tokenId?: string | null;
  tokenNumber?: number | null;
  actionType: AuditEntry['actionType'];
  actor: string;
  reason: string;
}): void {
  const id = `audit-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  db.prepare(
    `INSERT INTO audit_logs (
      id, doctor_id, doctor_name, shift_id, token_id, token_number, action_type, actor, reason, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    params.doctorId,
    params.doctorName,
    params.shiftId,
    params.tokenId ?? null,
    params.tokenNumber ?? null,
    params.actionType,
    params.actor,
    params.reason,
    new Date().toISOString()
  );
}

export function getDirectory(): {clinics: Clinic[]; doctors: DirectoryDoctor[]} {
  const clinicRows = db.prepare('SELECT * FROM clinics ORDER BY name ASC').all() as ClinicRow[];
  const doctorRows = db.prepare('SELECT * FROM doctors ORDER BY name ASC').all() as DoctorRow[];
  const shiftRows = db.prepare('SELECT * FROM shifts').all() as ShiftRow[];

  const clinics = clinicRows.map(mapClinic);
  const clinicMap = new Map(clinics.map((c) => [c.id, c]));

  const doctors: DirectoryDoctor[] = doctorRows.map((dRow) => {
    const doc = mapDoctor(dRow);
    const clinic = clinicMap.get(doc.clinicId)!;
    const docShifts = shiftRows
      .filter((s) => s.doctor_id === doc.id)
      .sort((a, b) => (a.period === 'morning' ? -1 : 1) - (b.period === 'morning' ? -1 : 1))
      .map((sRow) => {
        const shift = mapShift(sRow);
        const activeQueue = getOrderedActiveQueue(shift.id);
        const current = activeQueue.find((t) => t.status === 'in_consultation') ?? null;
        const waitingCount = activeQueue.filter((t) => t.status !== 'in_consultation').length;
        const estimatedNextWaitMin = computeWaitMinutes(activeQueue.length, dRow);
        return {
          ...shift,
          waitingCount,
          currentTokenNumber: current ? current.token_number : null,
          estimatedNextWaitMin,
        };
      });

    return {
      ...doc,
      clinic,
      shifts: docShifts,
    };
  });

  // Put Dr. Arjun Mehta first so the primary demo doctor is effortless to find
  doctors.sort((a, b) => {
    if (a.id === 'doc-mehta') return -1;
    if (b.id === 'doc-mehta') return 1;
    return a.name.localeCompare(b.name);
  });

  return {clinics, doctors};
}

export function bookToken(input: {
  shiftId: string;
  patientName: string;
  contactNumber: string;
}): TokenTrackerView {
  const patientName = input.patientName.trim();
  const contactNumber = input.contactNumber.trim();
  if (!patientName) {
    throw new Error('Patient name is required.');
  }
  if (!contactNumber) {
    throw new Error('Contact number is required.');
  }

  const tx = db.transaction(() => {
    const shift = db.prepare('SELECT * FROM shifts WHERE id = ?').get(input.shiftId) as ShiftRow | undefined;
    if (!shift) {
      throw new Error('Selected consultation shift was not found.');
    }
    if (shift.is_active !== 1) {
      throw new Error('Selected consultation shift is not currently accepting tokens.');
    }

    const doctor = db.prepare('SELECT * FROM doctors WHERE id = ?').get(shift.doctor_id) as DoctorRow | undefined;
    if (!doctor) {
      throw new Error('Doctor record not found.');
    }

    const nextTokenNumber = shift.last_token_number + 1;
    const maxPriorityRow = db
      .prepare('SELECT COALESCE(MAX(priority_order), 0) as maxP FROM queue_tokens WHERE shift_id = ?')
      .get(shift.id) as {maxP: number};
    const nextPriority = Math.max(maxPriorityRow.maxP + 100, nextTokenNumber * 100);
    const tokenId = `tok-${shift.id}-${nextTokenNumber}-${Date.now().toString(36)}`;
    const nowIso = new Date().toISOString();

    db.prepare('UPDATE shifts SET last_token_number = ? WHERE id = ?').run(nextTokenNumber, shift.id);
    db.prepare(
      `INSERT INTO queue_tokens (
        id, shift_id, doctor_id, clinic_id, token_number, patient_name, contact_number,
        status, priority_order, is_emergency, booked_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'waiting', ?, 0, ?)`
    ).run(
      tokenId,
      shift.id,
      doctor.id,
      doctor.clinic_id,
      nextTokenNumber,
      patientName,
      contactNumber,
      nextPriority,
      nowIso
    );

    return tokenId;
  }).immediate;

  const createdId = tx();
  return getTokenTrackerView(createdId);
}

export function findTokenByShiftAndNumber(shiftId: string, tokenNumber: number): TokenTrackerView | null {
  const row = db
    .prepare('SELECT id FROM queue_tokens WHERE shift_id = ? AND token_number = ?')
    .get(shiftId, tokenNumber) as {id: string} | undefined;
  if (!row) return null;
  return getTokenTrackerView(row.id);
}

export function getTokenTrackerView(tokenId: string): TokenTrackerView {
  const tokenRow = db.prepare('SELECT * FROM queue_tokens WHERE id = ?').get(tokenId) as TokenRow | undefined;
  if (!tokenRow) {
    throw new Error('Queue token not found.');
  }
  const doctorRow = db.prepare('SELECT * FROM doctors WHERE id = ?').get(tokenRow.doctor_id) as DoctorRow;
  const clinicRow = db.prepare('SELECT * FROM clinics WHERE id = ?').get(tokenRow.clinic_id) as ClinicRow;
  const shiftRow = db.prepare('SELECT * FROM shifts WHERE id = ?').get(tokenRow.shift_id) as ShiftRow;

  const activeQueue = getOrderedActiveQueue(shiftRow.id);
  const currentRow = activeQueue.find((t) => t.status === 'in_consultation') ?? null;

  let patientsAhead = 0;
  if (tokenRow.status === 'waiting' || tokenRow.status === 'emergency') {
    const idx = activeQueue.findIndex((t) => t.id === tokenRow.id);
    patientsAhead = idx >= 0 ? idx : 0;
  }

  const estimatedWaitMinutes =
    tokenRow.status === 'waiting' || tokenRow.status === 'emergency'
      ? computeWaitMinutes(patientsAhead, doctorRow)
      : 0;

  const arrivalAlert =
    (tokenRow.status === 'waiting' || tokenRow.status === 'emergency') &&
    patientsAhead <= 2;

  return {
    token: mapToken(tokenRow),
    clinic: mapClinic(clinicRow),
    doctor: mapDoctor(doctorRow),
    shift: mapShift(shiftRow),
    currentTokenNumber: currentRow ? currentRow.token_number : null,
    patientsAhead,
    estimatedWaitMinutes,
    arrivalAlert,
    queueSnapshot: activeQueue.map((item) => ({
      tokenNumber: item.token_number,
      status: item.status as TokenStatus,
      isEmergency: item.is_emergency === 1,
      isCurrentUser: item.id === tokenRow.id,
    })),
    lastUpdatedAt: new Date().toISOString(),
  };
}

export function getDoctorConsoleData(doctorId: string, shiftId?: string): DoctorConsoleData {
  const doctorRow = db.prepare('SELECT * FROM doctors WHERE id = ?').get(doctorId) as DoctorRow | undefined;
  if (!doctorRow) {
    throw new Error('Doctor not found.');
  }
  const clinicRow = db.prepare('SELECT * FROM clinics WHERE id = ?').get(doctorRow.clinic_id) as ClinicRow;
  const shiftRows = (db.prepare('SELECT * FROM shifts WHERE doctor_id = ?').all(doctorId) as ShiftRow[]).sort(
    (a, b) => (a.period === 'morning' ? -1 : 1) - (b.period === 'morning' ? -1 : 1)
  );

  const activeShiftRow =
    (shiftId ? shiftRows.find((s) => s.id === shiftId) : undefined) ??
    shiftRows.find((s) => s.period === 'morning') ??
    shiftRows[0];

  if (!activeShiftRow) {
    throw new Error('No shifts configured for doctor.');
  }

  const allTokens = db
    .prepare('SELECT * FROM queue_tokens WHERE shift_id = ?')
    .all(activeShiftRow.id) as TokenRow[];

  const currentRow = allTokens.find((t) => t.status === 'in_consultation') ?? null;
  const waitingRows = allTokens
    .filter((t) => t.status === 'waiting' || t.status === 'emergency')
    .sort((a, b) => a.priority_order - b.priority_order || a.token_number - b.token_number);

  const absentRows = allTokens
    .filter((t) => t.status === 'absent')
    .sort((a, b) => a.token_number - b.token_number);

  const completedRows = allTokens
    .filter((t) => t.status === 'completed')
    .sort((a, b) => b.token_number - a.token_number);

  const hasCurrent = currentRow ? 1 : 0;
  const waitingQueue = waitingRows.map((row, idx) => ({
    ...mapToken(row),
    estimatedWaitMinutes: computeWaitMinutes(idx + hasCurrent, doctorRow),
  }));

  const auditRows = db
    .prepare('SELECT * FROM audit_logs WHERE doctor_id = ? ORDER BY created_at DESC LIMIT 20')
    .all(doctorId) as AuditRow[];

  return {
    doctor: mapDoctor(doctorRow),
    clinic: mapClinic(clinicRow),
    shifts: shiftRows.map(mapShift),
    activeShift: mapShift(activeShiftRow),
    currentToken: currentRow ? mapToken(currentRow) : null,
    waitingQueue,
    absentTokens: absentRows.map(mapToken),
    completedTokens: completedRows.map(mapToken),
    auditLogs: auditRows.map(mapAudit),
    lastUpdatedAt: new Date().toISOString(),
  };
}

function finalizeTokenAndUpdateEwma(
  tokenRow: TokenRow,
  doctorRow: DoctorRow,
  durationOverrideMin?: number,
  visitNotes?: string,
  prescriptionSummary?: string
): number {
  const now = Date.now();
  const nowIso = new Date(now).toISOString();

  let actualDuration = doctorRow.default_duration_min;
  if (typeof durationOverrideMin === 'number' && Number.isFinite(durationOverrideMin)) {
    actualDuration = Math.min(45, Math.max(5, Math.round(durationOverrideMin)));
  } else if (tokenRow.called_at) {
    const elapsedMin = (now - new Date(tokenRow.called_at).getTime()) / 60_000;
    // Use real elapsed minutes when consultation lasts >= 1 minute; in quick demo clicks preserve baseline pace
    if (elapsedMin >= 1) {
      actualDuration = Math.min(45, Math.max(5, Math.round(elapsedMin)));
    }
  }

  const nextEwma = Number(
    (EWMA_ALPHA * actualDuration + (1 - EWMA_ALPHA) * doctorRow.ewma_pace_min).toFixed(1)
  );
  const clampedEwma = Math.min(45, Math.max(5, nextEwma));

  db.prepare(
    `UPDATE queue_tokens
     SET status = 'completed',
         completed_at = ?,
         duration_minutes = ?,
         visit_notes = COALESCE(?, visit_notes),
         prescription_summary = COALESCE(?, prescription_summary)
     WHERE id = ? AND status = 'in_consultation'`
  ).run(
    nowIso,
    actualDuration,
    visitNotes?.trim() || null,
    prescriptionSummary?.trim() || null,
    tokenRow.id
  );

  db.prepare('UPDATE doctors SET ewma_pace_min = ? WHERE id = ?').run(clampedEwma, doctorRow.id);
  return clampedEwma;
}

export function callNextPatient(input: {
  doctorId: string;
  shiftId: string;
  durationOverrideMin?: number;
}): {console: DoctorConsoleData; message: string} {
  const tx = db.transaction(() => {
    const doctorRow = db.prepare('SELECT * FROM doctors WHERE id = ?').get(input.doctorId) as DoctorRow | undefined;
    if (!doctorRow) throw new Error('Doctor not found.');

    const currentRow = db
      .prepare("SELECT * FROM queue_tokens WHERE shift_id = ? AND status = 'in_consultation' LIMIT 1")
      .get(input.shiftId) as TokenRow | undefined;

    let completedMsg = '';
    if (currentRow) {
      finalizeTokenAndUpdateEwma(currentRow, doctorRow, input.durationOverrideMin);
      completedMsg = `Completed Token #${currentRow.token_number}. `;
    }

    const nextRow = getOrderedWaitingQueue(input.shiftId)[0];
    if (nextRow) {
      const result = db
        .prepare(
          `UPDATE queue_tokens
           SET status = 'in_consultation', called_at = ?
           WHERE id = ? AND status IN ('waiting', 'emergency')`
        )
        .run(new Date().toISOString(), nextRow.id);

      if (result.changes === 0) {
        throw new Error('Next token state changed concurrently. Please retry.');
      }

      const nextAvailability: DoctorAvailability =
        doctorRow.delay_minutes > 0 ? 'delayed' : 'in_consultation';
      db.prepare('UPDATE doctors SET availability = ? WHERE id = ?').run(nextAvailability, doctorRow.id);

      return `${completedMsg}Now serving Token #${nextRow.token_number}.`;
    }

    const idleAvailability: DoctorAvailability =
      doctorRow.delay_minutes > 0 ? 'delayed' : 'available';
    db.prepare('UPDATE doctors SET availability = ? WHERE id = ?').run(idleAvailability, doctorRow.id);
    return `${completedMsg}No waiting patients remain in this shift.`;
  }).immediate;

  const message = tx();
  return {
    console: getDoctorConsoleData(input.doctorId, input.shiftId),
    message,
  };
}

export function completeCurrentConsultation(input: {
  doctorId: string;
  shiftId: string;
  durationOverrideMin?: number;
  visitNotes?: string;
  prescriptionSummary?: string;
}): {console: DoctorConsoleData; completedTokenId: string; message: string} {
  const tx = db.transaction(() => {
    const doctorRow = db.prepare('SELECT * FROM doctors WHERE id = ?').get(input.doctorId) as DoctorRow | undefined;
    if (!doctorRow) throw new Error('Doctor not found.');

    const currentRow = db
      .prepare("SELECT * FROM queue_tokens WHERE shift_id = ? AND status = 'in_consultation' LIMIT 1")
      .get(input.shiftId) as TokenRow | undefined;
    if (!currentRow) {
      throw new Error('No patient is currently in consultation.');
    }

    finalizeTokenAndUpdateEwma(
      currentRow,
      doctorRow,
      input.durationOverrideMin,
      input.visitNotes,
      input.prescriptionSummary
    );

    const nextAvailability: DoctorAvailability =
      doctorRow.delay_minutes > 0 ? 'delayed' : 'available';
    db.prepare('UPDATE doctors SET availability = ? WHERE id = ?').run(nextAvailability, doctorRow.id);

    return {
      completedTokenId: currentRow.id,
      message: `Marked Token #${currentRow.token_number} as completed.`,
    };
  }).immediate;

  const result = tx();
  return {
    console: getDoctorConsoleData(input.doctorId, input.shiftId),
    ...result,
  };
}

export function updateVisitNotes(input: {
  tokenId: string;
  visitNotes: string;
  prescriptionSummary: string;
}): QueueToken {
  const tx = db.transaction(() => {
    const row = db.prepare('SELECT * FROM queue_tokens WHERE id = ?').get(input.tokenId) as TokenRow | undefined;
    if (!row) throw new Error('Token not found.');

    db.prepare(
      `UPDATE queue_tokens
       SET visit_notes = ?, prescription_summary = ?
       WHERE id = ?`
    ).run(input.visitNotes.trim(), input.prescriptionSummary.trim(), input.tokenId);

    const updated = db.prepare('SELECT * FROM queue_tokens WHERE id = ?').get(input.tokenId) as TokenRow;
    return mapToken(updated);
  }).immediate;

  return tx();
}

export function addDoctorDelay(input: {
  doctorId: string;
  shiftId: string;
  minutes: number;
  reason?: string;
}): {console: DoctorConsoleData; message: string} {
  const tx = db.transaction(() => {
    const doctorRow = db.prepare('SELECT * FROM doctors WHERE id = ?').get(input.doctorId) as DoctorRow | undefined;
    if (!doctorRow) throw new Error('Doctor not found.');

    const nextDelay = Math.max(0, doctorRow.delay_minutes + input.minutes);
    const nextAvailability: DoctorAvailability = nextDelay > 0 ? 'delayed' : 'in_consultation';

    db.prepare('UPDATE doctors SET delay_minutes = ?, availability = ? WHERE id = ?').run(
      nextDelay,
      nextAvailability,
      doctorRow.id
    );

    insertAuditLog({
      doctorId: doctorRow.id,
      doctorName: doctorRow.name,
      shiftId: input.shiftId,
      actionType: 'delay_added',
      actor: doctorRow.name,
      reason:
        input.reason?.trim() ||
        (input.minutes > 0
          ? `Added +${input.minutes} min clinic delay (total delay: ${nextDelay} min).`
          : 'Cleared active clinic delay; doctor back on schedule.'),
    });

    return input.minutes > 0
      ? `Added ${input.minutes}-minute delay. Wait estimates updated across the queue.`
      : 'Delay cleared. Wait estimates recalculated.';
  }).immediate;

  const message = tx();
  return {
    console: getDoctorConsoleData(input.doctorId, input.shiftId),
    message,
  };
}

export function markTokenAbsent(input: {
  doctorId: string;
  shiftId: string;
  tokenId?: string;
}): {console: DoctorConsoleData; message: string} {
  const tx = db.transaction(() => {
    const doctorRow = db.prepare('SELECT * FROM doctors WHERE id = ?').get(input.doctorId) as DoctorRow | undefined;
    if (!doctorRow) throw new Error('Doctor not found.');

    let targetRow: TokenRow | undefined;
    if (input.tokenId) {
      targetRow = db
        .prepare(
          "SELECT * FROM queue_tokens WHERE id = ? AND shift_id = ? AND status IN ('in_consultation', 'waiting', 'emergency')"
        )
        .get(input.tokenId, input.shiftId) as TokenRow | undefined;
    } else {
      targetRow =
        (db
          .prepare("SELECT * FROM queue_tokens WHERE shift_id = ? AND status = 'in_consultation' LIMIT 1")
          .get(input.shiftId) as TokenRow | undefined) ?? getOrderedWaitingQueue(input.shiftId)[0];
    }

    if (!targetRow) {
      throw new Error('No active or waiting token available to mark absent.');
    }

    const wasInConsultation = targetRow.status === 'in_consultation';
    db.prepare("UPDATE queue_tokens SET status = 'absent' WHERE id = ?").run(targetRow.id);

    insertAuditLog({
      doctorId: doctorRow.id,
      doctorName: doctorRow.name,
      shiftId: input.shiftId,
      tokenId: targetRow.id,
      tokenNumber: targetRow.token_number,
      actionType: 'patient_absent',
      actor: doctorRow.name,
      reason: `Token #${targetRow.token_number} marked absent and moved to holding bay.`,
    });

    let advancedMsg = '';
    if (wasInConsultation) {
      const nextWaiting = getOrderedWaitingQueue(input.shiftId)[0];
      if (nextWaiting) {
        db.prepare(
          "UPDATE queue_tokens SET status = 'in_consultation', called_at = ? WHERE id = ?"
        ).run(new Date().toISOString(), nextWaiting.id);
        advancedMsg = ` Advanced queue to Token #${nextWaiting.token_number}.`;
      } else {
        const idleAvail: DoctorAvailability = doctorRow.delay_minutes > 0 ? 'delayed' : 'available';
        db.prepare('UPDATE doctors SET availability = ? WHERE id = ?').run(idleAvail, doctorRow.id);
      }
    }

    return `Token #${targetRow.token_number} skipped to holding bay.${advancedMsg}`;
  }).immediate;

  const message = tx();
  return {
    console: getDoctorConsoleData(input.doctorId, input.shiftId),
    message,
  };
}

export function restoreAbsentToken(input: {
  tokenId: string;
}): {console: DoctorConsoleData; message: string} {
  const tx = db.transaction(() => {
    const row = db
      .prepare("SELECT * FROM queue_tokens WHERE id = ? AND status = 'absent'")
      .get(input.tokenId) as TokenRow | undefined;
    if (!row) {
      throw new Error('Token is not currently in the absent holding bay.');
    }
    const doctorRow = db.prepare('SELECT * FROM doctors WHERE id = ?').get(row.doctor_id) as DoctorRow;

    const minWaitingRow = db
      .prepare(
        "SELECT MIN(priority_order) as minP FROM queue_tokens WHERE shift_id = ? AND status IN ('waiting', 'emergency')"
      )
      .get(row.shift_id) as {minP: number | null};

    const nextPriority = minWaitingRow.minP !== null ? minWaitingRow.minP - 25 : row.token_number * 100;
    db.prepare("UPDATE queue_tokens SET status = 'waiting', priority_order = ? WHERE id = ?").run(
      nextPriority,
      row.id
    );

    insertAuditLog({
      doctorId: doctorRow.id,
      doctorName: doctorRow.name,
      shiftId: row.shift_id,
      tokenId: row.id,
      tokenNumber: row.token_number,
      actionType: 'token_restored',
      actor: 'Clinic Staff',
      reason: `Returning absent patient Token #${row.token_number} restored to next in line.`,
    });

    return {
      doctorId: row.doctor_id,
      shiftId: row.shift_id,
      message: `Restored Token #${row.token_number} to the active queue.`,
    };
  }).immediate;

  const res = tx();
  return {
    console: getDoctorConsoleData(res.doctorId, res.shiftId),
    message: res.message,
  };
}

export function escalateEmergency(input: {
  doctorId: string;
  shiftId: string;
  tokenId?: string;
  patientName?: string;
  contactNumber?: string;
  reason: string;
  staffActor?: string;
}): {console: DoctorConsoleData; token: QueueToken; message: string} {
  const reason = input.reason.trim();
  if (!reason) {
    throw new Error('An escalation reason is required for the clinical audit log.');
  }

  const tx = db.transaction(() => {
    const doctorRow = db.prepare('SELECT * FROM doctors WHERE id = ?').get(input.doctorId) as DoctorRow | undefined;
    const shiftRow = db.prepare('SELECT * FROM shifts WHERE id = ?').get(input.shiftId) as ShiftRow | undefined;
    if (!doctorRow || !shiftRow) {
      throw new Error('Doctor or shift not found.');
    }

    const minWaitingRow = db
      .prepare(
        "SELECT MIN(priority_order) as minP FROM queue_tokens WHERE shift_id = ? AND status IN ('waiting', 'emergency')"
      )
      .get(shiftRow.id) as {minP: number | null};
    const urgentPriority = (minWaitingRow.minP ?? 100) - 50;

    let targetId = input.tokenId;
    let tokenNumber: number;

    if (targetId) {
      const existing = db
        .prepare("SELECT * FROM queue_tokens WHERE id = ? AND shift_id = ? AND status IN ('waiting', 'emergency')")
        .get(targetId, shiftRow.id) as TokenRow | undefined;
      if (!existing) {
        throw new Error('Selected token cannot be escalated.');
      }
      tokenNumber = existing.token_number;
      db.prepare(
        "UPDATE queue_tokens SET status = 'emergency', is_emergency = 1, priority_order = ? WHERE id = ?"
      ).run(urgentPriority, existing.id);
    } else {
      const pName = input.patientName?.trim();
      const pPhone = input.contactNumber?.trim() || '+91 98000 00911';
      if (!pName) {
        throw new Error('Patient name is required for a walk-in emergency escalation.');
      }
      tokenNumber = shiftRow.last_token_number + 1;
      targetId = `tok-emg-${shiftRow.id}-${tokenNumber}-${Date.now().toString(36)}`;
      db.prepare('UPDATE shifts SET last_token_number = ? WHERE id = ?').run(tokenNumber, shiftRow.id);
      db.prepare(
        `INSERT INTO queue_tokens (
          id, shift_id, doctor_id, clinic_id, token_number, patient_name, contact_number,
          status, priority_order, is_emergency, booked_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'emergency', ?, 1, ?)`
      ).run(
        targetId,
        shiftRow.id,
        doctorRow.id,
        doctorRow.clinic_id,
        tokenNumber,
        pName,
        pPhone,
        urgentPriority,
        new Date().toISOString()
      );
    }

    insertAuditLog({
      doctorId: doctorRow.id,
      doctorName: doctorRow.name,
      shiftId: shiftRow.id,
      tokenId: targetId,
      tokenNumber,
      actionType: 'emergency_escalation',
      actor: input.staffActor?.trim() || 'Triage Nurse / Staff',
      reason,
    });

    const updatedToken = db.prepare('SELECT * FROM queue_tokens WHERE id = ?').get(targetId) as TokenRow;
    return {
      token: mapToken(updatedToken),
      message: `Emergency escalation applied: Token #${tokenNumber} prioritized to front of queue.`,
    };
  }).immediate;

  const res = tx();
  return {
    console: getDoctorConsoleData(input.doctorId, input.shiftId),
    token: res.token,
    message: res.message,
  };
}

function haversineMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371_000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

export function checkInWithProximity(input: {
  tokenId: string;
  lat: number;
  lng: number;
}): {
  checkedIn: boolean;
  distanceMeters: number;
  message: string;
  tracker: TokenTrackerView;
} {
  const tokenRow = db.prepare('SELECT * FROM queue_tokens WHERE id = ?').get(input.tokenId) as TokenRow | undefined;
  if (!tokenRow) throw new Error('Token not found.');
  const clinicRow = db.prepare('SELECT * FROM clinics WHERE id = ?').get(tokenRow.clinic_id) as ClinicRow;

  const distanceMeters = haversineMeters(input.lat, input.lng, clinicRow.lat, clinicRow.lng);
  if (distanceMeters <= 500) {
    db.prepare('UPDATE queue_tokens SET checked_in_at = ?, check_in_distance_m = ? WHERE id = ?').run(
      new Date().toISOString(),
      distanceMeters,
      tokenRow.id
    );
    return {
      checkedIn: true,
      distanceMeters,
      message: `Checked in at ${clinicRow.name} (${distanceMeters}m from clinic reception).`,
      tracker: getTokenTrackerView(tokenRow.id),
    };
  }

  return {
    checkedIn: false,
    distanceMeters,
    message: `You are ${distanceMeters.toLocaleString()}m away. Proximity check-in unlocks within 500m of ${clinicRow.name}.`,
    tracker: getTokenTrackerView(tokenRow.id),
  };
}

export function getPublicBoard(clinicId?: string): PublicBoardEntry[] {
  const clinics = db.prepare('SELECT * FROM clinics').all() as ClinicRow[];
  const clinicMap = new Map(clinics.map((c) => [c.id, c]));

  const doctors = (
    clinicId
      ? db.prepare('SELECT * FROM doctors WHERE clinic_id = ?').all(clinicId)
      : db.prepare('SELECT * FROM doctors').all()
  ) as DoctorRow[];

  const entries: PublicBoardEntry[] = [];

  for (const doc of doctors) {
    const clinic = clinicMap.get(doc.clinic_id)!;
    const shifts = db
      .prepare('SELECT * FROM shifts WHERE doctor_id = ? AND is_active = 1')
      .all(doc.id) as ShiftRow[];

    // Select the shift with active/waiting patients, defaulting to Morning shift
    let chosenShift = shifts.find((s) => s.period === 'morning') ?? shifts[0];
    for (const s of shifts) {
      const q = getOrderedActiveQueue(s.id);
      if (q.length > 0) {
        chosenShift = s;
        break;
      }
    }
    if (!chosenShift) continue;

    const activeQueue = getOrderedActiveQueue(chosenShift.id);
    const current = activeQueue.find((t) => t.status === 'in_consultation') ?? null;
    const waiting = activeQueue.filter((t) => t.status !== 'in_consultation');
    const next = waiting[0] ?? null;

    let activeNotice: string | null = null;
    if (next?.is_emergency === 1 || current?.is_emergency === 1) {
      activeNotice = 'Priority triage case active';
    } else if (doc.delay_minutes > 0) {
      activeNotice = `Running +${doc.delay_minutes} min behind schedule`;
    } else if (doc.availability === 'on_break') {
      activeNotice = 'Between shifts · Resumes 16:00';
    }

    entries.push({
      doctorId: doc.id,
      doctorName: doc.name,
      specialty: doc.specialty as Specialty,
      roomNumber: doc.room_number,
      clinicId: clinic.id,
      clinicName: clinic.name,
      shiftId: chosenShift.id,
      shiftLabel: chosenShift.label,
      availability: doc.availability as DoctorAvailability,
      delayMinutes: doc.delay_minutes,
      ewmaPaceMin: doc.ewma_pace_min,
      currentTokenNumber: current ? current.token_number : null,
      currentIsEmergency: current ? current.is_emergency === 1 : false,
      nextTokenNumber: next ? next.token_number : null,
      waitingCount: waiting.length,
      activeNotice,
    });
  }

  entries.sort((a, b) => {
    if (a.doctorId === 'doc-mehta') return -1;
    if (b.doctorId === 'doc-mehta') return 1;
    return (b.waitingCount > 0 ? 1 : 0) - (a.waitingCount > 0 ? 1 : 0);
  });

  return entries;
}

export function getHeatmap(clinicId?: string): HeatmapCell[] {
  if (clinicId && clinicId !== 'all') {
    const rows = db
      .prepare('SELECT clinic_id, day_of_week, hour_label, avg_wait_min, patient_volume FROM wait_time_history WHERE clinic_id = ?')
      .all(clinicId) as Array<{
      clinic_id: string;
      day_of_week: string;
      hour_label: string;
      avg_wait_min: number;
      patient_volume: number;
    }>;
    return rows.map((r) => ({
      clinicId: r.clinic_id,
      dayOfWeek: r.day_of_week,
      hourLabel: r.hour_label,
      avgWaitMin: r.avg_wait_min,
      patientVolume: r.patient_volume,
    }));
  }

  const rows = db
    .prepare(
      `SELECT day_of_week, hour_label,
              ROUND(AVG(avg_wait_min)) as avg_wait_min,
              SUM(patient_volume) as patient_volume
       FROM wait_time_history
       GROUP BY day_of_week, hour_label`
    )
    .all() as Array<{
    day_of_week: string;
    hour_label: string;
    avg_wait_min: number;
    patient_volume: number;
  }>;

  return rows.map((r) => ({
    clinicId: 'all',
    dayOfWeek: r.day_of_week,
    hourLabel: r.hour_label,
    avgWaitMin: r.avg_wait_min,
    patientVolume: r.patient_volume,
  }));
}

export function getRecentAuditLogs(limit = 30): AuditEntry[] {
  const rows = db
    .prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT ?')
    .all(limit) as AuditRow[];
  return rows.map(mapAudit);
}
