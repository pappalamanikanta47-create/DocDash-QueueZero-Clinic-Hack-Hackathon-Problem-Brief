import {BrowserRouter, Route, Routes} from 'react-router-dom';
import {TopBar} from './client/components/TopBar';
import {DirectoryPage} from './client/pages/DirectoryPage';
import {PatientTrackerPage} from './client/pages/PatientTrackerPage';
import {DoctorConsolePage} from './client/pages/DoctorConsolePage';
import {WaitingBoardPage} from './client/pages/WaitingBoardPage';
import {DemoSplitPage} from './client/pages/DemoSplitPage';
import {AnalyticsPage} from './client/pages/AnalyticsPage';

export default function App() {
  return (
    <BrowserRouter>
      <div className="flex min-h-screen flex-col">
        <TopBar />
        <div className="flex-1">
          <Routes>
            <Route path="/" element={<DirectoryPage />} />
            <Route path="/track" element={<PatientTrackerPage />} />
            <Route path="/track/:tokenId" element={<PatientTrackerPage />} />
            <Route path="/doctor" element={<DoctorConsolePage />} />
            <Route path="/board" element={<WaitingBoardPage />} />
            <Route path="/demo" element={<DemoSplitPage />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
          </Routes>
        </div>
        <footer className="border-t border-slate-200 bg-white px-4 py-5 text-xs text-slate-500 sm:px-6 lg:px-8">
          <div className="mx-auto flex max-w-[1360px] flex-wrap items-center justify-between gap-2">
            <span>DocDash: QueueZero · Outpatient Clinic Queue Management</span>
            <span>Wait times are approximate and adjust dynamically with consultation pace.</span>
          </div>
        </footer>
      </div>
    </BrowserRouter>
  );
}
