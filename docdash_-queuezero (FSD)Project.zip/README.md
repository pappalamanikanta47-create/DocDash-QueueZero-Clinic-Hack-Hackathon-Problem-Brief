# DocDash: QueueZero

Outpatient clinic appointment booking, live virtual queue tracking, dynamic EWMA wait-time estimation, doctor/staff control console, and privacy-safe public waiting-room board.

## Setup & Run Instructions

1. **Install dependencies**
   ```bash
   npm install
   ```
2. **Start development server (Express + SQLite + WebSockets + Vite on port 3000)**
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser. On first boot, `queuezero.db` is initialized and deterministically seeded with 4 city clinics, 8 specialists across 4 departments, morning/evening shifts, active queues, wait-time heatmap history, and audit entries.
3. **Production build & start**
   ```bash
   npm run build
   NODE_ENV=production npm start
   ```
4. **Type-check**
   ```bash
   npm run lint
   ```

## Repeatable Dr. Mehta Demo Scenario

1. Navigate to **Live Demo** (`/demo`) or book **Dr. Arjun Mehta (Cardiology — Morning Shift)** from the main Directory (`/`).
2. Book **Token #14** as **Patient A**. The patient tracker initially shows **Token #11** in consultation, **3 patients ahead**, and an estimated **36 min** wait.
3. In the right-hand **Doctor Control Console**, click **Call Next Patient**.
4. The patient view immediately updates via WebSocket to **2 patients ahead**, **24 min** estimated wait, and displays the amber **"Please arrive at the clinic now"** alert, while the public waiting-room preview updates in lockstep without exposing personal details.
5. Click **Reset Demo State** at any time to restore the canonical starting queue (`#11` in consultation, `#12`–`#13` waiting, next booking `#14`).

## Dynamic Wait-Time Calculation (EWMA)

Wait times are recalculated on the server after every queue transition using an Exponentially Weighted Moving Average (EWMA) of each doctor's consultation pace:

- **Pace Update**: $\text{pace}_{\text{new}} = \alpha \cdot d_{\text{last}} + (1 - \alpha) \cdot \text{pace}_{\text{prev}}$, with smoothing factor $\alpha = 0.35$ and bounds $[5, 45]$ minutes.
- **Estimated Wait**: $\text{wait} = \max\bigl(0,\; \text{round}(\text{patientsAhead} \times \text{pace} + \text{delayMinutes})\bigr)$, where `patientsAhead` counts the active `in_consultation` token plus any higher-priority `waiting` or `emergency` tokens ahead of the patient.
- Estimates are always presented as approximate rather than guaranteed appointment times.

## Demo Data Model

- **Clinics (`clinics`)**: 4 branches in one city with addresses, phone numbers, and latitude/longitude coordinates for optional 500m proximity check-in.
- **Doctors (`doctors`)**: 8 specialists across General Medicine, Pediatrics, Orthopedics, and Cardiology, each storing `default_duration_min`, `ewma_pace_min`, `delay_minutes`, and live `availability`.
- **Shifts (`shifts`)**: Morning (`09:00–13:00`) and Evening (`16:00–20:00`) consultation shifts per doctor with atomic sequential `last_token_number` counters.
- **Queue Tokens (`queue_tokens`)**: Shift-scoped tokens tracking `status` (`waiting`, `in_consultation`, `delayed`, `completed`, `absent`, `emergency`), `priority_order` (for emergency escalation and absent restoration without renumbering), optional proximity check-in distance, and post-visit notes/prescriptions.
- **Wait-Time History (`wait_time_history`) & Audit Logs (`audit_logs`)**: Historical day/hour congestion series powering the clinic heatmap, plus immutable records for delays, absent skips, restorations, and emergency escalations.
