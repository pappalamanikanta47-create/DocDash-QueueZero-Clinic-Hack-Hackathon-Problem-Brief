# DocDash: QueueZero — Implementation Plan

DocDash: QueueZero is a real-time outpatient clinic appointment and virtual queue management application connecting patients, doctors/clinic staff, and public waiting-room displays through a unified live queue engine.

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and UX choices were confirmed during intake and govern the full implementation. Please review and approve to begin building.

- **Backend & Real-Time Sync**: Node.js + Express REST API backed by persistent SQLite storage and a WebSocket server on port 3000 so every queue mutation broadcasts immediately to all open views.
- **Stretch Features Included**: Full inclusion of the Clinic Wait-Time Heatmap, opt-in 500m Proximity Check-In, Visit Notes & Prescription Summaries on completed tokens, and Staff Emergency Escalation with queue recalculation and an audit log.
- **Visual Direction**: Crisp daylight clinical interface (`#F8FAFC` canvas, `#FFFFFF` structural surfaces) for patient and doctor workflows paired with a high-contrast dark kiosk mode (`#0F172A`) dedicated to the public waiting-room display board.
- **Demo & Navigation Model**: Dedicated URL routes for each role (`/`, `/track/:tokenId`, `/doctor`, `/board`, `/analytics`) plus an interactive split-screen **Dr. Mehta Live Demo Mode** (`/demo`) with one-click reset to replay the Token #11 to Token #14 scenario.

---

### 1. Overview & Core Concept

- **What It Does**: Eliminates uncertain outpatient waiting times by issuing shift-scoped sequential virtual tokens, dynamically estimating waits using each doctor's recent consultation pace, and syncing live queue state across patient trackers, doctor consoles, and lobby displays.
- **Target Personas**:
  - **Patients** browsing clinics by specialty, booking a morning/evening shift token with minimal friction, tracking live queue position, optionally checking in on arrival within 500m, and viewing post-visit notes.
  - **Doctors & Clinic Staff** advancing queues with atomic actions (Call Next, Mark Completed, Delay 10m, Mark Absent, Emergency Escalate) and attaching concise visit summaries.
  - **Public Waiting-Room Viewers** scanning a glare-free, privacy-safe lobby board displaying only token numbers, room/doctor status, and approximate wait pace—never patient names or phone numbers.
- **Key Value**: Patients time their clinic arrival confidently (triggered by an amber arrival alert at 2 tokens away), while staff keep consultation throughput moving smoothly even when patients are absent or emergencies arise.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Directory & Virtual Token Booking**: Patients land on the Clinic & Doctor Directory, filter across 4 city clinics and 4 specialties (General Medicine, Pediatrics, Orthopedics, Cardiology), inspect doctor availability/fees/average duration, select an active Morning or Evening shift, and submit only Name + Contact Number to receive a sequential token confirmation and jump straight into live tracking.
  2. **Live Patient Queue Tracker**: Displays the patient's token number, token currently in consultation, count of patients ahead, doctor status (`On Time`, `Delayed`, `In Consultation`, `Break`), approximate EWMA wait estimate (labeled explicitly as approximate), live WebSocket connection status, and a subtle countdown/refresh indicator. When `2 tokens away`, an amber banner announces *"Please arrive at the clinic now"*. Upon completion, patients can inspect attached prescription/visit notes; when within 500m (if they explicitly enable check-in), they can mark themselves *Arrived*.
  3. **Doctor Control Console**: Workspace for selecting a clinic/doctor/shift, viewing the ordered active queue plus a holding list for absent/skipped patients, and executing single-click atomic actions (`Call Next Patient`, `Mark Completed`, `Delay 10 Minutes`, `Patient Absent — Skip Token`, `Emergency Escalate`) with immediate confirmation banners and optional visit-note entry on completion.
  4. **Public Waiting-Room Board**: High-contrast dark display readable across a room, showing **Now Serving** token, **Next Up** token, doctor/shift status, and active emergency/delay notices without exposing any personal patient details.
  5. **Dr. Mehta Split-Screen Demo Mode**: Side-by-side workspace pairing **Patient A's Live Tracker (Cardiology — Dr. Mehta)** on the left, **Dr. Mehta's Control Console** on the right, and a compact **Lobby Board Preview** below, plus a prominent **Reset Demo State** control and step guide.
  6. **Clinic Analytics & Architecture Guide**: Dedicated view hosting the interactive **Wait-Time Heatmap** (historical average waits by day of week and clinic hour) alongside a concise visual explanation of the EWMA wait-time formula and data model.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Calm, trustworthy modern healthcare operations—clean geometric structure, generous breathing room, hairline 1px borders (`#E2E8F0` light / `#1E293B` dark), single-elevation flat surfaces, and zero nested card clutter.
  - *Color Palette (60-30-10)*:
    - **60% Canvas**: Crisp Clinical Mist (`#F8FAFC`) on patient/doctor/analytics views; Deep Slate (`#0F172A`) on the public waiting-room board.
    - **30% Structural Surfaces**: Pure White (`#FFFFFF`) and Cool Slate (`#F1F5F9`) containers with subtle `#E2E8F0` borders (light), or `#1E293B` panels with `#334155` borders (dark board).
    - **10% Accent & Semantic Status** (always paired with explicit text labels and icons, never color alone): Deep Clinical Teal (`#0D9488`) for primary actions, Emerald (`#16A34A`) for active/on-time states, Amber (`#D97706`) for 2-tokens-away arrival alerts and delays, Crimson (`#DC2626`) for emergency escalations/absent warnings.
  - *Typography & Hierarchy*: `Plus Jakarta Sans` for headings and top-bar navigation, `DM Sans` for crisp UI prose, and `JetBrains Mono` with `tabular-nums` on every token number (`#14`), wait estimate (`24 min`), timestamp, and heatmap cell so numbers align cleanly without jitter.
  - *Navigation & Metadata Discipline*: Clean 3-zone top bar (`DocDash` wordmark · 5 single-line route links · `Live Demo` primary action). Static metadata (specialty, clinic branch, fee, duration) renders as unboxed text separated by `·` rather than pill-badge clusters.
  - *Bespoke Visual Assets*: Custom studio-lit medical portrait illustrations/headshots for our seeded doctors generated cleanly to eliminate external image dependencies, paired with resilient SVG monogram fallbacks.

- **Interactive Feedback & State Completeness**:
  - Fast $\le 200\text{ms}$ compositor transitions (`transform`/`opacity`) respecting `prefers-reduced-motion`.
  - Explicit skeleton loaders matching layout geometry, informative empty queues with clear recovery actions, non-blocking inline error banners with retry, and toast confirmations for every doctor/staff action.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Express + SQLite + WebSockets vs. In-Memory or Client-Only Store**
  - *Chosen Approach*: Persistent SQLite database accessed through an Express REST API on port 3000, paired with a native `ws` WebSocket broadcast layer sharing the same HTTP server.
  - *Why*: Survives page refreshes and server restarts, handles concurrent mutations cleanly inside SQLite transactions so a token can never be double-called, and pushes sub-second live updates to Patient, Doctor, and Waiting-Room views simultaneously.
  - *Trade-Off*: Requires server startup via `tsx` alongside Vite middleware in development and bundled output in production, which is straightforward and completely self-contained.

- **Decision 2: Dynamic Wait-Time Formula (EWMA + Delay & Emergency Adjustments)**
  - *Chosen Approach*: Each doctor maintains an Exponentially Weighted Moving Average (EWMA) consultation pace:
    $$\text{pace}_{\text{new}} = \alpha \cdot d_{\text{last}} + (1 - \alpha) \cdot \text{pace}_{\text{prev}} \quad (\alpha = 0.35)$$
    clamped within reasonable clinical bounds ($[5, 45]$ min). For a waiting token at queue index $k$ ahead of the currently serving consultation (where $k = 1$ means next up after the current patient, $k = 2$ means two patients ahead including the active consultation, etc.), estimated wait is:
    $$\text{wait} = \max\bigl(0,\; k \cdot \text{pace} + \text{doctorDelayMinutes} - \text{elapsedCurrentMinutes}\bigr)$$
    rounded to the nearest minute and always labeled as approximate.
  - *Why*: Responds smoothly when consultations run long or short without wildly oscillating on a single outlier. When seeded for Dr. Mehta with $\text{pace} = 12.0\text{ min}$ and Token #11 in consultation (0 elapsed at demo start), booking Token #14 yields $k = 3 \rightarrow 36\text{ min}$. Clicking **Call Next Patient** completes #11 in 12 min, advances #12 to consultation, and immediately recalculates Token #14 to $k = 2 \rightarrow 24\text{ min}$ while triggering the amber arrival alert.

- **Decision 3: Privacy-Safe Public Board & Opt-In Proximity Check-In**
  - *Chosen Approach*: Separate public-safe projection payload for `/board` (token numbers, status, doctor/room, wait pace—zero names or phone numbers). Geolocation API is invoked *only* when the user explicitly clicks **Check In at Clinic** on their token page, computing Haversine distance against the clinic's coordinates ($\le 500\text{m}$), with a graceful fallback explanation if denied or outside radius.
  - *Why*: Protects patient privacy on shared waiting-room screens and honors the strict requirement that location is never needed for booking or tracking.

- **Decision 4: Concurrency & Idempotent Demo Reset**
  - *Chosen Approach*: Queue transitions (`call-next`, `complete`, `delay`, `mark-absent`, `emergency-escalate`, `book`) execute inside atomic SQLite transactions checking current token status before mutating. A dedicated `POST /api/demo/reset` endpoint restores the canonical deterministic seed state in one transaction and broadcasts a `queue:reset` event to all clients.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

#### System & Component Architecture

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                         Client Views (React + Router)                        │
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │ Directory &  │  │ Live Patient │  │ Doctor/Staff │  │ Public Waiting   │  │
│  │ Token Book   │  │ Tracker      │  │ Console      │  │ Board (Dark)     │  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘  │
│         │                 │                 │                   │            │
│  ┌──────┴─────────────────┴─────────────────┴───────────────────┴─────────┐  │
│  │      Split-Screen Dr. Mehta Demo (/demo)  &  Heatmap + Docs (/analytics)│  │
│  └──────────────────────────────────┬─────────────────────────────────────┘  │
│                                     │                                        │
│                    Shared Queue Sync Hook (REST + WebSocket)                 │
└─────────────────────────────────────┼────────────────────────────────────────┘
                                      │ HTTP (fetch) + WS (/ws) on Port 3000
┌─────────────────────────────────────▼────────────────────────────────────────┐
│                       Node.js + Express + WebSocket Server                   │
│                                                                              │
│  ┌─────────────────────┐  ┌──────────────────────┐  ┌─────────────────────┐  │
│  │ REST API Routes     │  │ Queue Engine & EWMA  │  │ WebSocket Hub       │  │
│  │ /api/directory      │─▶│ Wait Calculator      │─▶│ Broadcasts delta &  │  │
│  │ /api/tokens/book    │  │ Atomic Transitions   │  │ full state updates  │  │
│  │ /api/doctor/actions │  │ Emergency Escalation │  │ on every mutation   │  │
│  │ /api/demo/reset     │  │ 500m Haversine Check │  └─────────────────────┘  │
│  └─────────────────────┘  └──────────┬───────────┘                           │
│                                      │                                       │
│                           ┌──────────▼───────────┐                           │
│                           │  SQLite Database     │                           │
│                           │  (Transactions +     │                           │
│                           │   Deterministic Seed)│                           │
│                           └──────────────────────┘                           │
└──────────────────────────────────────────────────────────────────────────────┘
```

#### Data Model & State Entities

- **Clinics (4 seeded across one metro area)**: ID, name, neighborhood/address, latitude, longitude (used strictly for opt-in 500m check-in), phone, room prefix.
- **Doctors (8 seeded across General Medicine, Pediatrics, Orthopedics, Cardiology)**: ID, clinic ID, full name, specialty, avatar image, consultation fee, default average duration, current EWMA pace (`ewma_pace_min`), active delay offset (`delay_minutes`), availability status (`available`, `in_consultation`, `delayed`, `on_break`).
- **Shifts (Morning & Evening per doctor)**: ID, doctor ID, label (`Morning 09:00–13:00`, `Evening 16:00–20:00`), active flag, next sequential token counter (`last_token_number`).
- **Queue Tokens / Appointments**: ID, shift ID, doctor ID, clinic ID, sequential `token_number`, `patient_name`, `contact_number`, `status` (`waiting`, `in_consultation`, `delayed`, `completed`, `absent`, `emergency`), `priority_order` (allows emergency escalation ahead of standard queue without renumbering issued tokens), `booked_at`, `called_at`, `completed_at`, `checked_in_at`, `check_in_distance_m`, `visit_notes`, `prescription_summary`.
- **Wait-Time History**: Clinic ID, doctor ID, day of week (`Mon`–`Sat`), hour slot (`09:00`–`19:00`), average wait minutes, patient volume (drives the clinic wait-time heatmap).
- **Emergency & Queue Audit Log**: ID, doctor ID, shift ID, token ID, action type (`emergency_escalation`, `delay_added`, `patient_absent`, `demo_reset`), staff actor, reason/note, timestamp.

#### Interactive Component & State Mapping

- **Directory Filters & Booking Modal**: Filters doctor list live by clinic and specialty; submitting patient name + contact calls `POST /api/tokens/book`, allocates `last_token_number + 1` inside a SQLite transaction, navigates to `/track/:tokenId` (or updates the Demo split view), and broadcasts `queue:updated`.
- **Patient Tracker & Stretch Actions**: Subscribes via WebSocket (with silent reconnect and fallback poll) to compute `patientsAhead`, `currentToken`, and approximate `estimatedWaitMinutes`. Renders the amber arrival banner whenever `patientsAhead <= 2 && status === 'waiting'`. Clicking **Check In Within 500m** triggers browser geolocation, verifies distance via `POST /api/tokens/:id/checkin`, and displays exact meter distance or helpful permission/range feedback. When status reaches `completed`, renders the **Visit Summary & Prescription** panel.
- **Doctor Control Console**: Displays active consultation card, waiting queue ordered by `priority_order`, and skipped/absent holding list.
  - **Call Next Patient**: Completes any active `in_consultation` token (recording actual duration and updating doctor's EWMA pace), promotes the highest-priority `waiting` token to `in_consultation`, clears transient per-turn flags, and broadcasts recalculated waits.
  - **Mark Completed**: Completes the active token and opens an inline **Visit Notes & Prescription** composer (`PATCH /api/tokens/:id/notes`) with pre-built clinical templates or custom text.
  - **Delay 10 Minutes**: Increments doctor's `delay_minutes` by 10, marks doctor status `Delayed (+10m)`, logs to audit table, and recalculates all waiting token ETAs.
  - **Patient Absent — Skip Token**: Moves the currently called or next waiting patient to `absent` (holding bay with a one-click **Restore to Queue** option) and advances the next waiting patient without blocking flow.
  - **Emergency Escalation**: Modal/inline action for staff to insert or promote an urgent token to top priority (`priority_order`), record a mandatory escalation reason in the audit log, and immediately recompute wait estimates across the shift.
- **Dr. Mehta Split-Screen Demo (`/demo`)**: Automatically surfaces Dr. Mehta's Morning Cardiology shift with Tokens #1–#10 completed, #11 in consultation, #12–#13 waiting, and Patient A's Token #14 ready (or 1-click booked) at 36 min wait. Clicking **Call Next Patient** on the right pane updates the left patient pane instantaneously to 2 patients ahead, 24 min estimated wait, and the amber *"Please arrive at the clinic now"* alert. **Reset Demo** calls `POST /api/demo/reset` to restore the exact starting state on demand.
