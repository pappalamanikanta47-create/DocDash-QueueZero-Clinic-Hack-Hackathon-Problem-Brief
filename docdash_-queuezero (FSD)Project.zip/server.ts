import express from 'express';
import http from 'http';
import path from 'path';
import {fileURLToPath} from 'url';
import {WebSocketServer, WebSocket} from 'ws';
import {createServer as createViteServer} from 'vite';
import {ensureInitialized, resetAndSeedDatabase} from './src/server/db.ts';
import {
  addDoctorDelay,
  bookToken,
  callNextPatient,
  checkInWithProximity,
  completeCurrentConsultation,
  escalateEmergency,
  findTokenByShiftAndNumber,
  getDirectory,
  getDoctorConsoleData,
  getHeatmap,
  getPublicBoard,
  getRecentAuditLogs,
  getTokenTrackerView,
  markTokenAbsent,
  restoreAbsentToken,
  updateVisitNotes,
} from './src/server/queueEngine.ts';
import type {WsEvent} from './src/shared/types.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = 3000;

async function startServer() {
  ensureInitialized();

  const app = express();
  app.use(express.json());

  const server = http.createServer(app);
  const wss = new WebSocketServer({server, path: '/ws'});

  function broadcast(event: WsEvent) {
    const payload = JSON.stringify(event);
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    }
  }

  wss.on('connection', (socket) => {
    const welcome: WsEvent = {
      type: 'connected',
      timestamp: new Date().toISOString(),
    };
    socket.send(JSON.stringify(welcome));
  });

  // Health & Directory
  app.get('/api/directory', (_req, res) => {
    try {
      res.json(getDirectory());
    } catch (err) {
      res.status(500).json({error: (err as Error).message});
    }
  });

  // Token Booking & Lookup
  app.post('/api/tokens/book', (req, res) => {
    try {
      const {shiftId, patientName, contactNumber} = req.body ?? {};
      const tracker = bookToken({shiftId, patientName, contactNumber});
      broadcast({
        type: 'queue:updated',
        doctorId: tracker.doctor.id,
        shiftId: tracker.shift.id,
        timestamp: new Date().toISOString(),
      });
      res.status(201).json(tracker);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  app.get('/api/tokens/lookup', (req, res) => {
    try {
      const shiftId = String(req.query.shiftId || '');
      const tokenNumber = Number(req.query.tokenNumber || 0);
      if (!shiftId || !tokenNumber) {
        return res.status(400).json({error: 'shiftId and tokenNumber are required.'});
      }
      const tracker = findTokenByShiftAndNumber(shiftId, tokenNumber);
      if (!tracker) {
        return res.status(404).json({error: 'Token not found for this shift.'});
      }
      res.json(tracker);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  app.get('/api/tokens/:id', (req, res) => {
    try {
      res.json(getTokenTrackerView(req.params.id));
    } catch (err) {
      res.status(404).json({error: (err as Error).message});
    }
  });

  app.post('/api/tokens/:id/checkin', (req, res) => {
    try {
      const lat = Number(req.body?.lat);
      const lng = Number(req.body?.lng);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
        return res.status(400).json({error: 'Valid latitude and longitude are required.'});
      }
      const result = checkInWithProximity({tokenId: req.params.id, lat, lng});
      if (result.checkedIn) {
        broadcast({
          type: 'queue:updated',
          doctorId: result.tracker.doctor.id,
          shiftId: result.tracker.shift.id,
          timestamp: new Date().toISOString(),
        });
      }
      res.json(result);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  app.patch('/api/tokens/:id/notes', (req, res) => {
    try {
      const {visitNotes, prescriptionSummary} = req.body ?? {};
      const updated = updateVisitNotes({
        tokenId: req.params.id,
        visitNotes: String(visitNotes ?? ''),
        prescriptionSummary: String(prescriptionSummary ?? ''),
      });
      broadcast({
        type: 'queue:updated',
        doctorId: updated.doctorId,
        shiftId: updated.shiftId,
        timestamp: new Date().toISOString(),
      });
      res.json(updated);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  // Doctor Control Console Endpoints
  app.get('/api/doctor/:doctorId', (req, res) => {
    try {
      const shiftId = req.query.shiftId ? String(req.query.shiftId) : undefined;
      res.json(getDoctorConsoleData(req.params.doctorId, shiftId));
    } catch (err) {
      res.status(404).json({error: (err as Error).message});
    }
  });

  app.post('/api/doctor/:doctorId/call-next', (req, res) => {
    try {
      const {shiftId, durationOverrideMin} = req.body ?? {};
      const result = callNextPatient({
        doctorId: req.params.doctorId,
        shiftId: String(shiftId),
        durationOverrideMin:
          typeof durationOverrideMin === 'number' ? durationOverrideMin : undefined,
      });
      broadcast({
        type: 'queue:updated',
        doctorId: req.params.doctorId,
        shiftId: result.console.activeShift.id,
        timestamp: new Date().toISOString(),
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  app.post('/api/doctor/:doctorId/complete', (req, res) => {
    try {
      const {shiftId, durationOverrideMin, visitNotes, prescriptionSummary} = req.body ?? {};
      const result = completeCurrentConsultation({
        doctorId: req.params.doctorId,
        shiftId: String(shiftId),
        durationOverrideMin:
          typeof durationOverrideMin === 'number' ? durationOverrideMin : undefined,
        visitNotes,
        prescriptionSummary,
      });
      broadcast({
        type: 'queue:updated',
        doctorId: req.params.doctorId,
        shiftId: result.console.activeShift.id,
        timestamp: new Date().toISOString(),
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  app.post('/api/doctor/:doctorId/delay', (req, res) => {
    try {
      const {shiftId, minutes, reason} = req.body ?? {};
      const result = addDoctorDelay({
        doctorId: req.params.doctorId,
        shiftId: String(shiftId),
        minutes: Number(minutes ?? 10),
        reason,
      });
      broadcast({
        type: 'queue:updated',
        doctorId: req.params.doctorId,
        shiftId: result.console.activeShift.id,
        timestamp: new Date().toISOString(),
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  app.post('/api/doctor/:doctorId/absent', (req, res) => {
    try {
      const {shiftId, tokenId} = req.body ?? {};
      const result = markTokenAbsent({
        doctorId: req.params.doctorId,
        shiftId: String(shiftId),
        tokenId: tokenId ? String(tokenId) : undefined,
      });
      broadcast({
        type: 'queue:updated',
        doctorId: req.params.doctorId,
        shiftId: result.console.activeShift.id,
        timestamp: new Date().toISOString(),
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  app.post('/api/tokens/:id/restore', (req, res) => {
    try {
      const result = restoreAbsentToken({tokenId: req.params.id});
      broadcast({
        type: 'queue:updated',
        doctorId: result.console.doctor.id,
        shiftId: result.console.activeShift.id,
        timestamp: new Date().toISOString(),
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  app.post('/api/doctor/:doctorId/escalate', (req, res) => {
    try {
      const {shiftId, tokenId, patientName, contactNumber, reason, staffActor} = req.body ?? {};
      const result = escalateEmergency({
        doctorId: req.params.doctorId,
        shiftId: String(shiftId),
        tokenId: tokenId ? String(tokenId) : undefined,
        patientName,
        contactNumber,
        reason: String(reason ?? ''),
        staffActor,
      });
      broadcast({
        type: 'queue:updated',
        doctorId: req.params.doctorId,
        shiftId: result.console.activeShift.id,
        timestamp: new Date().toISOString(),
      });
      res.status(201).json(result);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  // Public Waiting-Room Board (PII-free)
  app.get('/api/board', (req, res) => {
    try {
      const clinicId = req.query.clinicId ? String(req.query.clinicId) : undefined;
      res.json({
        entries: getPublicBoard(clinicId && clinicId !== 'all' ? clinicId : undefined),
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      res.status(500).json({error: (err as Error).message});
    }
  });

  // Analytics & Audit Log
  app.get('/api/analytics/heatmap', (req, res) => {
    try {
      const clinicId = req.query.clinicId ? String(req.query.clinicId) : 'all';
      res.json({
        cells: getHeatmap(clinicId),
        auditLogs: getRecentAuditLogs(25),
      });
    } catch (err) {
      res.status(500).json({error: (err as Error).message});
    }
  });

  // Deterministic Demo Reset
  app.post('/api/demo/reset', (_req, res) => {
    try {
      resetAndSeedDatabase();
      broadcast({
        type: 'queue:reset',
        doctorId: 'doc-mehta',
        shiftId: 'shift-mehta-morning',
        timestamp: new Date().toISOString(),
      });
      res.json({
        ok: true,
        message: 'Demo state restored: Dr. Mehta is serving Token #11 (next booking is Token #14).',
      });
    } catch (err) {
      res.status(500).json({error: (err as Error).message});
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`DocDash: QueueZero listening on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
